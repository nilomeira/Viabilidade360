# Viabilidade360

Simulador financeiro interativo para análise de viabilidade de negócios.
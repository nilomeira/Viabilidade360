import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Alert,
  Snackbar
} from '@mui/material';
import { useNavigate, useLocation } from 'react-router-dom';
import SimulationManager from '../utils/SimulationManager';
import ReportGenerator from '../utils/ReportGenerator';
import { SimulationInput, SimulationResult } from '../types/financialTypes';

/**
 * Componente para integrar a geração de relatórios com a interface do usuário
 */
const ReportService: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const simulationManager = SimulationManager.getInstance();
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [reportType, setReportType] = useState<string>('');
  const [openDialog, setOpenDialog] = useState(false);
  
  /**
   * Gera um relatório em PDF
   * @param type Tipo de relatório a ser gerado
   */
  const generateReport = (type: string) => {
    setReportType(type);
    setOpenDialog(true);
  };
  
  /**
   * Confirma a geração do relatório
   */
  const confirmGenerateReport = () => {
    setOpenDialog(false);
    setLoading(true);
    
    try {
      const input = simulationManager.getSimulationInput();
      const results = simulationManager.getSimulationResults();
      
      if (!input || !results) {
        setError('Não há dados de simulação disponíveis. Execute uma simulação primeiro.');
        setLoading(false);
        return;
      }
      
      // Usar o cenário realista para os relatórios
      const realisticResult = results.realistic;
      
      // Criar o gerador de relatórios
      const reportGenerator = new ReportGenerator(input, realisticResult);
      
      // Gerar o relatório de acordo com o tipo selecionado
      let pdfDoc;
      
      switch (reportType) {
        case 'full':
          pdfDoc = reportGenerator.generateFullReport();
          break;
        case 'dre':
          pdfDoc = reportGenerator.generateIncomeStatementReport();
          break;
        case 'cashflow':
          pdfDoc = reportGenerator.generateCashFlowReport();
          break;
        case 'indicators':
          pdfDoc = reportGenerator.generateFinancialIndicatorsReport();
          break;
        default:
          pdfDoc = reportGenerator.generateFullReport();
      }
      
      // Gerar nome do arquivo
      const projectName = input.basicInfo.projectName || 'projeto';
      const fileName = `${projectName.replace(/\s+/g, '_').toLowerCase()}_${reportType}_${new Date().toISOString().split('T')[0]}.pdf`;
      
      // Salvar o PDF
      pdfDoc.save(fileName);
      
      setSuccess(`Relatório ${fileName} gerado com sucesso!`);
    } catch (err) {
      console.error('Erro ao gerar relatório:', err);
      setError('Ocorreu um erro ao gerar o relatório. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Cancela a geração do relatório
   */
  const cancelGenerateReport = () => {
    setOpenDialog(false);
  };
  
  /**
   * Fecha as mensagens de alerta
   */
  const handleCloseAlert = () => {
    setError(null);
    setSuccess(null);
  };
  
  return (
    <>
      {/* Botões para geração de relatórios */}
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={() => generateReport('full')}
          disabled={loading}
        >
          Gerar Relatório Completo
        </Button>
        
        <Button 
          variant="outlined" 
          color="primary" 
          onClick={() => generateReport('dre')}
          disabled={loading}
        >
          Gerar Relatório de DRE
        </Button>
        
        <Button 
          variant="outlined" 
          color="primary" 
          onClick={() => generateReport('cashflow')}
          disabled={loading}
        >
          Gerar Relatório de Fluxo de Caixa
        </Button>
        
        <Button 
          variant="outlined" 
          color="primary" 
          onClick={() => generateReport('indicators')}
          disabled={loading}
        >
          Gerar Relatório de Indicadores
        </Button>
      </Box>
      
      {/* Dialog de confirmação */}
      <Dialog open={openDialog} onClose={cancelGenerateReport}>
        <DialogTitle>Confirmar Geração de Relatório</DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            Você está prestes a gerar um relatório em PDF. Deseja continuar?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={cancelGenerateReport} color="primary">
            Cancelar
          </Button>
          <Button onClick={confirmGenerateReport} color="primary" variant="contained">
            Gerar Relatório
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Indicador de carregamento */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      )}
      
      {/* Mensagens de alerta */}
      <Snackbar open={!!error} autoHideDuration={6000} onClose={handleCloseAlert}>
        <Alert onClose={handleCloseAlert} severity="error" sx={{ width: '100%' }}>
          {error}
        </Alert>
      </Snackbar>
      
      <Snackbar open={!!success} autoHideDuration={6000} onClose={handleCloseAlert}>
        <Alert onClose={handleCloseAlert} severity="success" sx={{ width: '100%' }}>
          {success}
        </Alert>
      </Snackbar>
    </>
  );
};

export default ReportService;

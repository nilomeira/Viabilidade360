// Tipos de dados para os cálculos financeiros
export interface BasicInfo {
  projectName: string;
  sector: string;
  startDate: string;
  projectionPeriod: number;
  currency: string;
  discountRate: number;
  description: string;
}

export interface Investment {
  category: string;
  value: number;
  lifespan: number;
}

export interface Revenue {
  name: string;
  unitPrice: number;
  monthlyQuantity: number;
}

export interface VariableCost {
  productId: number;
  rawMaterial: number;
  packaging: number;
  commissions: number;
  taxes: number;
}

export interface FixedCost {
  name: string;
  monthlyValue: number;
}

export interface Financing {
  ownCapital: number;
  loanAmount: number;
  annualInterestRate: number;
  termMonths: number;
  graceMonths: number;
  system: string;
}

export interface SimulationInput {
  basicInfo: BasicInfo;
  investments: Investment[];
  revenues: Revenue[];
  annualGrowth: number[];
  variableCosts: VariableCost[];
  fixedCosts: FixedCost[];
  financing: Financing;
}

export interface IncomeStatementItem {
  year: number;
  grossRevenue: number;
  taxes: number;
  netRevenue: number;
  variableCosts: number;
  grossMargin: number;
  fixedCosts: number;
  operatingProfit: number;
  depreciation: number;
  interest: number;
  ebt: number;
  incomeTax: number;
  netProfit: number;
}

export interface CashFlowItem {
  year: number;
  operationalCashFlow: number;
  investmentCashFlow: number;
  financingCashFlow: number;
  netCashFlow: number;
  accumulatedCashFlow: number;
}

export interface FinancialIndicators {
  irr: number;
  npv: number;
  paybackPeriod: number;
  discountedPaybackPeriod: number;
  breakEvenPoint: number;
}

export interface SimulationResult {
  summary: FinancialIndicators;
  incomeStatement: IncomeStatementItem[];
  cashFlow: CashFlowItem[];
}

export interface ScenarioResults {
  pessimistic: SimulationResult;
  realistic: SimulationResult;
  optimistic: SimulationResult;
}

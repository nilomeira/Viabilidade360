import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Card, 
  CardContent,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Divider,
  Alert,
  List,
  ListItem,
  ListItemText
} from '@mui/material';
import SimulationManager from '../utils/SimulationManager';
import { testCaseSmallClothingStore, testCaseCoffeeShop, testCaseSoftwareCompany } from '../utils/testCases';
import { runFinancialSimulation } from '../utils/financialCalculations';
import { ScenarioResults } from '../types/financialTypes';

const TestPage: React.FC = () => {
  const [testResults, setTestResults] = useState<{
    clothingStore: ScenarioResults | null,
    coffeeShop: ScenarioResults | null,
    softwareCompany: ScenarioResults | null
  }>({
    clothingStore: null,
    coffeeShop: null,
    softwareCompany: null
  });
  
  const [testStatus, setTestStatus] = useState<{
    clothingStore: string,
    coffeeShop: string,
    softwareCompany: string
  }>({
    clothingStore: 'Não executado',
    coffeeShop: 'Não executado',
    softwareCompany: 'Não executado'
  });
  
  const [overallStatus, setOverallStatus] = useState<'success' | 'error' | 'warning' | 'info'>('info');
  const [statusMessage, setStatusMessage] = useState<string>('Testes não executados');

  // Função para executar os testes
  const runTests = () => {
    try {
      // Teste da loja de roupas
      const clothingStoreInput = testCaseSmallClothingStore();
      const clothingStoreResults = runFinancialSimulation(clothingStoreInput);
      setTestResults(prev => ({ ...prev, clothingStore: clothingStoreResults }));
      
      // Verificar resultados da loja de roupas
      const clothingStoreValid = validateResults(clothingStoreResults);
      setTestStatus(prev => ({ 
        ...prev, 
        clothingStore: clothingStoreValid ? 'Sucesso' : 'Falha - Resultados inconsistentes' 
      }));
      
      // Teste da cafeteria
      const coffeeShopInput = testCaseCoffeeShop();
      const coffeeShopResults = runFinancialSimulation(coffeeShopInput);
      setTestResults(prev => ({ ...prev, coffeeShop: coffeeShopResults }));
      
      // Verificar resultados da cafeteria
      const coffeeShopValid = validateResults(coffeeShopResults);
      setTestStatus(prev => ({ 
        ...prev, 
        coffeeShop: coffeeShopValid ? 'Sucesso' : 'Falha - Resultados inconsistentes' 
      }));
      
      // Teste da empresa de software
      const softwareCompanyInput = testCaseSoftwareCompany();
      const softwareCompanyResults = runFinancialSimulation(softwareCompanyInput);
      setTestResults(prev => ({ ...prev, softwareCompany: softwareCompanyResults }));
      
      // Verificar resultados da empresa de software
      const softwareCompanyValid = validateResults(softwareCompanyResults);
      setTestStatus(prev => ({ 
        ...prev, 
        softwareCompany: softwareCompanyValid ? 'Sucesso' : 'Falha - Resultados inconsistentes' 
      }));
      
      // Atualizar status geral
      const allValid = clothingStoreValid && coffeeShopValid && softwareCompanyValid;
      setOverallStatus(allValid ? 'success' : 'error');
      setStatusMessage(allValid 
        ? 'Todos os testes foram executados com sucesso!' 
        : 'Alguns testes falharam. Verifique os resultados.'
      );
      
    } catch (error) {
      console.error('Erro ao executar testes:', error);
      setOverallStatus('error');
      setStatusMessage('Erro ao executar os testes. Verifique o console para mais detalhes.');
    }
  };
  
  // Função para validar os resultados
  const validateResults = (results: ScenarioResults | null): boolean => {
    if (!results) return false;
    
    // Verificar se os resultados são coerentes
    const realistic = results.realistic;
    
    // Verificar se os indicadores foram calculados
    if (
      realistic.summary.irr === undefined || 
      realistic.summary.npv === undefined || 
      realistic.summary.paybackPeriod === undefined || 
      realistic.summary.discountedPaybackPeriod === undefined || 
      realistic.summary.breakEvenPoint === undefined
    ) {
      return false;
    }
    
    // Verificar se o DRE foi calculado
    if (!realistic.incomeStatement || realistic.incomeStatement.length === 0) {
      return false;
    }
    
    // Verificar se o Fluxo de Caixa foi calculado
    if (!realistic.cashFlow || realistic.cashFlow.length === 0) {
      return false;
    }
    
    // Verificar se os cenários pessimista e otimista foram gerados
    if (!results.pessimistic || !results.optimistic) {
      return false;
    }
    
    // Verificar se os valores são coerentes
    // TIR do cenário otimista deve ser maior que do realista
    if (results.optimistic.summary.irr <= results.realistic.summary.irr) {
      return false;
    }
    
    // TIR do cenário pessimista deve ser menor que do realista
    if (results.pessimistic.summary.irr >= results.realistic.summary.irr) {
      return false;
    }
    
    // VPL do cenário otimista deve ser maior que do realista
    if (results.optimistic.summary.npv <= results.realistic.summary.npv) {
      return false;
    }
    
    // VPL do cenário pessimista deve ser menor que do realista
    if (results.pessimistic.summary.npv >= results.realistic.summary.npv) {
      return false;
    }
    
    return true;
  };
  
  // Formatar valores monetários
  const formatCurrency = (value: number) => {
    return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };
  
  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Testes do Simulador Financeiro
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Verificação do funcionamento correto do aplicativo com casos de uso reais
        </Typography>
      </Box>
      
      <Grid container spacing={4}>
        {/* Painel de controle de testes */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Painel de Controle
            </Typography>
            
            <Box sx={{ mt: 2, mb: 3 }}>
              <Button 
                variant="contained" 
                color="primary" 
                onClick={runTests}
                sx={{ mr: 2 }}
              >
                Executar Todos os Testes
              </Button>
            </Box>
            
            <Alert severity={overallStatus} sx={{ mb: 2 }}>
              {statusMessage}
            </Alert>
            
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Caso de Teste</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>TIR (Realista)</TableCell>
                    <TableCell>VPL (Realista)</TableCell>
                    <TableCell>Payback</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>Boutique de Roupas</TableCell>
                    <TableCell>{testStatus.clothingStore}</TableCell>
                    <TableCell>
                      {testResults.clothingStore ? 
                        `${testResults.clothingStore.realistic.summary.irr}%` : 
                        '-'}
                    </TableCell>
                    <TableCell>
                      {testResults.clothingStore ? 
                        formatCurrency(testResults.clothingStore.realistic.summary.npv) : 
                        '-'}
                    </TableCell>
                    <TableCell>
                      {testResults.clothingStore ? 
                        `${testResults.clothingStore.realistic.summary.paybackPeriod} anos` : 
                        '-'}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Café Especial</TableCell>
                    <TableCell>{testStatus.coffeeShop}</TableCell>
                    <TableCell>
                      {testResults.coffeeShop ? 
                        `${testResults.coffeeShop.realistic.summary.irr}%` : 
                        '-'}
                    </TableCell>
                    <TableCell>
                      {testResults.coffeeShop ? 
                        formatCurrency(testResults.coffeeShop.realistic.summary.npv) : 
                        '-'}
                    </TableCell>
                    <TableCell>
                      {testResults.coffeeShop ? 
                        `${testResults.coffeeShop.realistic.summary.paybackPeriod} anos` : 
                        '-'}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Empresa de Software</TableCell>
                    <TableCell>{testStatus.softwareCompany}</TableCell>
                    <TableCell>
                      {testResults.softwareCompany ? 
                        `${testResults.softwareCompany.realistic.summary.irr}%` : 
                        '-'}
                    </TableCell>
                    <TableCell>
                      {testResults.softwareCompany ? 
                        formatCurrency(testResults.softwareCompany.realistic.summary.npv) : 
                        '-'}
                    </TableCell>
                    <TableCell>
                      {testResults.softwareCompany ? 
                        `${testResults.softwareCompany.realistic.summary.paybackPeriod} anos` : 
                        '-'}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
        
        {/* Detalhes dos testes */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, borderRadius: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Verificações Realizadas
            </Typography>
            
            <List>
              <ListItem>
                <ListItemText 
                  primary="Cálculo de Indicadores" 
                  secondary="Verifica se TIR, VPL, Payback, Payback Descontado e Ponto de Equilíbrio são calculados corretamente."
                />
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Demonstrativo de Resultados" 
                  secondary="Verifica se o DRE é gerado para todos os anos do período de projeção."
                />
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Fluxo de Caixa" 
                  secondary="Verifica se o Fluxo de Caixa é calculado corretamente, incluindo o investimento inicial."
                />
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Cenários Alternativos" 
                  secondary="Verifica se os cenários pessimista e otimista são gerados e se seus valores são coerentes em relação ao cenário realista."
                />
              </ListItem>
              <ListItem>
                <ListItemText 
                  primary="Coerência dos Resultados" 
                  secondary="Verifica se os resultados são matematicamente coerentes e se seguem as regras financeiras esperadas."
                />
              </ListItem>
            </List>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, borderRadius: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Análise dos Resultados
            </Typography>
            
            {testResults.clothingStore && testResults.coffeeShop && testResults.softwareCompany ? (
              <Box>
                <Typography variant="subtitle1" gutterBottom>
                  Comparação entre os Negócios
                </Typography>
                
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Negócio</TableCell>
                        <TableCell align="right">TIR</TableCell>
                        <TableCell align="right">VPL</TableCell>
                        <TableCell align="right">Payback</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>Boutique de Roupas</TableCell>
                        <TableCell align="right">{testResults.clothingStore.realistic.summary.irr}%</TableCell>
                        <TableCell align="right">{formatCurrency(testResults.clothingStore.realistic.summary.npv)}</TableCell>
                        <TableCell align="right">{testResults.clothingStore.realistic.summary.paybackPeriod} anos</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Café Especial</TableCell>
                        <TableCell align="right">{testResults.coffeeShop.realistic.summary.irr}%</TableCell>
                        <TableCell align="right">{formatCurrency(testResults.coffeeShop.realistic.summary.npv)}</TableCell>
                        <TableCell align="right">{testResults.coffeeShop.realistic.summary.paybackPeriod} anos</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Empresa de Software</TableCell>
                        <TableCell align="right">{testResults.softwareCompany.realistic.summary.irr}%</TableCell>
                        <TableCell align="right">{formatCurrency(testResults.softwareCompany.realistic.summary.npv)}</TableCell>
                        <TableCell align="right">{testResults.softwareCompany.realistic.summary.paybackPeriod} anos</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
                
                <Typography variant="body2" sx={{ mt: 3 }}>
                  A análise comparativa mostra que a Empresa de Software apresenta os melhores indicadores financeiros, 
                  com maior TIR e VPL, seguida pelo Café Especial e pela Boutique de Roupas. Isso é coerente com as 
                  características de cada negócio, onde empresas de tecnologia tendem a ter margens maiores e crescimento 
                  mais acelerado, enquanto negócios de varejo como a boutique de roupas geralmente têm margens menores 
                  e crescimento mais moderado.
                </Typography>
              </Box>
            ) : (
              <Typography variant="body2" color="text.secondary">
                Execute os testes para ver a análise comparativa dos resultados.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default TestPage;

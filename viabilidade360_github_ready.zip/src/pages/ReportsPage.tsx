import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Card, 
  CardContent, 
  Button,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import DownloadIcon from '@mui/icons-material/Download';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableChartIcon from '@mui/icons-material/TableChart';
import BarChartIcon from '@mui/icons-material/BarChart';
import EmailIcon from '@mui/icons-material/Email';
import ShareIcon from '@mui/icons-material/Share';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DescriptionIcon from '@mui/icons-material/Description';
import AssessmentIcon from '@mui/icons-material/Assessment';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';

// Interface para a TabPanel
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// Componente TabPanel
const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Componente de visualização de relatório (simulado)
const ReportPreview = () => (
  <Box sx={{ height: 500, bgcolor: 'rgba(25, 118, 210, 0.05)', borderRadius: 2, p: 2, border: '1px dashed rgba(25, 118, 210, 0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
    <DescriptionIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2, opacity: 0.7 }} />
    <Typography variant="body2" color="text.secondary" align="center">
      Visualização do Relatório (Simulado)<br />
      Clique em "Exportar PDF" para gerar o relatório completo
    </Typography>
  </Box>
);

const ReportsPage: React.FC = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Relatórios Detalhados
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Visualize e exporte relatórios completos da sua simulação financeira
        </Typography>
      </Box>

      <Grid container spacing={4}>
        {/* Seleção de relatórios */}
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Relatórios Disponíveis
            </Typography>
            <List component="nav">
              <ListItem 
                button 
                selected={tabValue === 0}
                onClick={(event) => handleTabChange(event, 0)}
                sx={{ 
                  borderRadius: 1,
                  mb: 1,
                  '&.Mui-selected': {
                    backgroundColor: 'primary.light',
                    color: 'white',
                    '&:hover': {
                      backgroundColor: 'primary.main',
                    },
                    '& .MuiListItemIcon-root': {
                      color: 'white',
                    },
                  },
                }}
              >
                <ListItemIcon>
                  <DescriptionIcon />
                </ListItemIcon>
                <ListItemText primary="DRE Anual" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === 1}
                onClick={(event) => handleTabChange(event, 1)}
                sx={{ 
                  borderRadius: 1,
                  mb: 1,
                  '&.Mui-selected': {
                    backgroundColor: 'primary.light',
                    color: 'white',
                    '&:hover': {
                      backgroundColor: 'primary.main',
                    },
                    '& .MuiListItemIcon-root': {
                      color: 'white',
                    },
                  },
                }}
              >
                <ListItemIcon>
                  <AccountBalanceIcon />
                </ListItemIcon>
                <ListItemText primary="Fluxo de Caixa" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === 2}
                onClick={(event) => handleTabChange(event, 2)}
                sx={{ 
                  borderRadius: 1,
                  mb: 1,
                  '&.Mui-selected': {
                    backgroundColor: 'primary.light',
                    color: 'white',
                    '&:hover': {
                      backgroundColor: 'primary.main',
                    },
                    '& .MuiListItemIcon-root': {
                      color: 'white',
                    },
                  },
                }}
              >
                <ListItemIcon>
                  <AssessmentIcon />
                </ListItemIcon>
                <ListItemText primary="Indicadores" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === 3}
                onClick={(event) => handleTabChange(event, 3)}
                sx={{ 
                  borderRadius: 1,
                  mb: 1,
                  '&.Mui-selected': {
                    backgroundColor: 'primary.light',
                    color: 'white',
                    '&:hover': {
                      backgroundColor: 'primary.main',
                    },
                    '& .MuiListItemIcon-root': {
                      color: 'white',
                    },
                  },
                }}
              >
                <ListItemIcon>
                  <CompareArrowsIcon />
                </ListItemIcon>
                <ListItemText primary="Análise de Cenários" />
              </ListItem>
              
              <ListItem 
                button 
                selected={tabValue === 4}
                onClick={(event) => handleTabChange(event, 4)}
                sx={{ 
                  borderRadius: 1,
                  mb: 1,
                  '&.Mui-selected': {
                    backgroundColor: 'primary.light',
                    color: 'white',
                    '&:hover': {
                      backgroundColor: 'primary.main',
                    },
                    '& .MuiListItemIcon-root': {
                      color: 'white',
                    },
                  },
                }}
              >
                <ListItemIcon>
                  <AttachMoneyIcon />
                </ListItemIcon>
                <ListItemText primary="Financiamento" />
              </ListItem>
              
              <Divider sx={{ my: 2 }} />
              
              <ListItem 
                button 
                sx={{ 
                  borderRadius: 1,
                  mb: 1,
                  backgroundColor: 'secondary.light',
                  color: 'white',
                  '&:hover': {
                    backgroundColor: 'secondary.main',
                  },
                  '& .MuiListItemIcon-root': {
                    color: 'white',
                  },
                }}
              >
                <ListItemIcon>
                  <PictureAsPdfIcon />
                </ListItemIcon>
                <ListItemText primary="Relatório Completo" />
              </ListItem>
            </List>
          </Paper>
          
          <Paper sx={{ p: 3, borderRadius: 2, mt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Opções de Exportação
            </Typography>
            <List>
              <ListItem button>
                <ListItemIcon>
                  <PictureAsPdfIcon />
                </ListItemIcon>
                <ListItemText primary="PDF" />
              </ListItem>
              <ListItem button>
                <ListItemIcon>
                  <TableChartIcon />
                </ListItemIcon>
                <ListItemText primary="Excel" />
              </ListItem>
              <ListItem button>
                <ListItemIcon>
                  <BarChartIcon />
                </ListItemIcon>
                <ListItemText primary="Apresentação" />
              </ListItem>
            </List>
            
            <Divider sx={{ my: 2 }} />
            
            <Typography variant="subtitle2" gutterBottom>
              Compartilhamento
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mt: 1 }}>
              <Button variant="outlined" size="small" startIcon={<EmailIcon />}>
                Email
              </Button>
              <Button variant="outlined" size="small" startIcon={<ShareIcon />}>
                Link
              </Button>
            </Box>
          </Paper>
        </Grid>
        
        {/* Visualização de relatórios */}
        <Grid item xs={12} md={9}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <TabPanel value={tabValue} index={0}>
              <Typography variant="h6" gutterBottom>
                Demonstrativo de Resultados do Exercício (DRE)
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Relatório financeiro que apresenta o desempenho operacional da empresa durante um período específico, mostrando receitas, custos, despesas e lucros.
              </Typography>
              <ReportPreview />
            </TabPanel>
            
            <TabPanel value={tabValue} index={1}>
              <Typography variant="h6" gutterBottom>
                Fluxo de Caixa Projetado
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Projeção detalhada das entradas e saídas de dinheiro ao longo do tempo, permitindo visualizar a liquidez do negócio nos próximos 10 anos.
              </Typography>
              <ReportPreview />
            </TabPanel>
            
            <TabPanel value={tabValue} index={2}>
              <Typography variant="h6" gutterBottom>
                Análise de Indicadores Financeiros
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Relatório detalhado dos principais indicadores de viabilidade econômica do projeto, incluindo TIR, VPL, Payback e Ponto de Equilíbrio.
              </Typography>
              <ReportPreview />
            </TabPanel>
            
            <TabPanel value={tabValue} index={3}>
              <Typography variant="h6" gutterBottom>
                Comparativo de Cenários
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Análise comparativa entre os cenários pessimista, realista e otimista, destacando as diferenças nos resultados financeiros e indicadores.
              </Typography>
              <ReportPreview />
            </TabPanel>
            
            <TabPanel value={tabValue} index={4}>
              <Typography variant="h6" gutterBottom>
                Análise de Financiamento
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Detalhamento do plano de financiamento, incluindo cronograma de pagamentos, juros, amortizações e impacto no fluxo de caixa.
              </Typography>
              <ReportPreview />
            </TabPanel>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
              <Button
                variant="outlined"
                startIcon={<ArrowBackIcon />}
                onClick={() => navigate('/dashboard')}
              >
                Voltar ao Dashboard
              </Button>
              
              <Button
                variant="contained"
                color="primary"
                startIcon={<DownloadIcon />}
              >
                Exportar PDF
              </Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ReportsPage;

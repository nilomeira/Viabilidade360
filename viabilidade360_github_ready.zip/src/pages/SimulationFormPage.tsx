import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Stepper, 
  Step, 
  StepLabel, 
  Button, 
  Paper,
  Grid,
  TextField,
  MenuItem,
  InputAdornment,
  Divider,
  IconButton,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  FormHelperText
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';

// Definição dos passos do formulário
const steps = [
  'Informações Básicas',
  'Investimentos',
  'Receitas',
  'Custos e Despesas',
  'Financiamento'
];

const SimulationFormPage: React.FC = () => {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  
  // Estados para os dados do formulário
  const [basicInfo, setBasicInfo] = useState({
    projectName: '',
    sector: '',
    startDate: '',
    projectionPeriod: 10,
    currency: 'R$',
    discountRate: 10,
    description: ''
  });
  
  const [investments, setInvestments] = useState([
    { category: 'Imóveis', value: 0, lifespan: 25 },
    { category: 'Equipamentos', value: 0, lifespan: 10 },
    { category: 'Veículos', value: 0, lifespan: 5 },
    { category: 'Mobiliário', value: 0, lifespan: 10 },
    { category: 'Software', value: 0, lifespan: 3 },
    { category: 'Marketing Inicial', value: 0, lifespan: 1 },
    { category: 'Capital de Giro', value: 0, lifespan: 0 }
  ]);
  
  const [revenues, setRevenues] = useState([
    { name: 'Produto/Serviço 1', unitPrice: 0, monthlyQuantity: 0 }
  ]);
  
  const [annualGrowth, setAnnualGrowth] = useState(Array(9).fill(5)); // 5% de crescimento anual padrão
  
  const [variableCosts, setVariableCosts] = useState([
    { productId: 0, rawMaterial: 30, packaging: 5, commissions: 5, taxes: 15 }
  ]);
  
  const [fixedCosts, setFixedCosts] = useState([
    { name: 'Aluguel', monthlyValue: 0 },
    { name: 'Salários', monthlyValue: 0 },
    { name: 'Encargos', monthlyValue: 0 },
    { name: 'Água/Luz', monthlyValue: 0 },
    { name: 'Internet/Telefone', monthlyValue: 0 },
    { name: 'Marketing', monthlyValue: 0 },
    { name: 'Manutenção', monthlyValue: 0 }
  ]);
  
  const [financing, setFinancing] = useState({
    ownCapital: 100,
    loanAmount: 0,
    annualInterestRate: 12,
    termMonths: 36,
    graceMonths: 0,
    system: 'SAC'
  });
  
  // Funções para manipulação dos dados
  const handleBasicInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setBasicInfo(prev => ({ ...prev, [name]: value }));
  };
  
  const handleInvestmentChange = (index: number, field: string, value: number) => {
    const newInvestments = [...investments];
    newInvestments[index] = { ...newInvestments[index], [field]: value };
    setInvestments(newInvestments);
  };
  
  const handleRevenueChange = (index: number, field: string, value: number | string) => {
    const newRevenues = [...revenues];
    newRevenues[index] = { ...newRevenues[index], [field]: value };
    setRevenues(newRevenues);
  };
  
  const addRevenue = () => {
    setRevenues([...revenues, { name: `Produto/Serviço ${revenues.length + 1}`, unitPrice: 0, monthlyQuantity: 0 }]);
    setVariableCosts([...variableCosts, { productId: revenues.length, rawMaterial: 30, packaging: 5, commissions: 5, taxes: 15 }]);
  };
  
  const removeRevenue = (index: number) => {
    if (revenues.length > 1) {
      const newRevenues = revenues.filter((_, i) => i !== index);
      const newVariableCosts = variableCosts.filter((_, i) => i !== index);
      setRevenues(newRevenues);
      setVariableCosts(newVariableCosts);
    }
  };
  
  const handleGrowthChange = (index: number, value: number) => {
    const newGrowth = [...annualGrowth];
    newGrowth[index] = value;
    setAnnualGrowth(newGrowth);
  };
  
  const handleVariableCostChange = (index: number, field: string, value: number) => {
    const newVariableCosts = [...variableCosts];
    newVariableCosts[index] = { ...newVariableCosts[index], [field]: value };
    setVariableCosts(newVariableCosts);
  };
  
  const handleFixedCostChange = (index: number, value: number) => {
    const newFixedCosts = [...fixedCosts];
    newFixedCosts[index] = { ...newFixedCosts[index], monthlyValue: value };
    setFixedCosts(newFixedCosts);
  };
  
  const addFixedCost = () => {
    setFixedCosts([...fixedCosts, { name: 'Novo Custo', monthlyValue: 0 }]);
  };
  
  const removeFixedCost = (index: number) => {
    if (fixedCosts.length > 1) {
      setFixedCosts(fixedCosts.filter((_, i) => i !== index));
    }
  };
  
  const handleFixedCostNameChange = (index: number, name: string) => {
    const newFixedCosts = [...fixedCosts];
    newFixedCosts[index] = { ...newFixedCosts[index], name };
    setFixedCosts(newFixedCosts);
  };
  
  const handleFinancingChange = (field: string, value: number | string) => {
    setFinancing(prev => ({ ...prev, [field]: value }));
  };
  
  // Cálculo do total de investimentos
  const totalInvestment = investments.reduce((sum, item) => sum + item.value, 0);
  
  // Navegação entre os passos
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSubmit = () => {
    // Aqui seria implementada a lógica para enviar os dados para processamento
    // e redirecionar para a página de resultados
    navigate('/dashboard');
  };

  // Renderização dos diferentes passos do formulário
  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Informações Básicas do Negócio
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  id="projectName"
                  name="projectName"
                  label="Nome do Projeto"
                  fullWidth
                  variant="outlined"
                  value={basicInfo.projectName}
                  onChange={handleBasicInfoChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  id="sector"
                  name="sector"
                  label="Setor de Atuação"
                  fullWidth
                  variant="outlined"
                  select
                  value={basicInfo.sector}
                  onChange={handleBasicInfoChange}
                >
                  <MenuItem value="Comércio">Comércio</MenuItem>
                  <MenuItem value="Serviços">Serviços</MenuItem>
                  <MenuItem value="Indústria">Indústria</MenuItem>
                  <MenuItem value="Tecnologia">Tecnologia</MenuItem>
                  <MenuItem value="Alimentação">Alimentação</MenuItem>
                  <MenuItem value="Saúde">Saúde</MenuItem>
                  <MenuItem value="Educação">Educação</MenuItem>
                  <MenuItem value="Outro">Outro</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  id="startDate"
                  name="startDate"
                  label="Data de Início"
                  type="date"
                  fullWidth
                  variant="outlined"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  value={basicInfo.startDate}
                  onChange={handleBasicInfoChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  id="projectionPeriod"
                  name="projectionPeriod"
                  label="Período de Projeção (anos)"
                  type="number"
                  fullWidth
                  variant="outlined"
                  value={basicInfo.projectionPeriod}
                  onChange={handleBasicInfoChange}
                  InputProps={{
                    readOnly: true, // Fixado em 10 anos conforme requisito
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  id="currency"
                  name="currency"
                  label="Moeda"
                  fullWidth
                  variant="outlined"
                  value={basicInfo.currency}
                  onChange={handleBasicInfoChange}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  id="discountRate"
                  name="discountRate"
                  label="Taxa de Desconto Anual"
                  type="number"
                  fullWidth
                  variant="outlined"
                  value={basicInfo.discountRate}
                  onChange={handleBasicInfoChange}
                  InputProps={{
                    endAdornment: <InputAdornment position="end">%</InputAdornment>,
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  id="description"
                  name="description"
                  label="Descrição do Projeto"
                  multiline
                  rows={4}
                  fullWidth
                  variant="outlined"
                  value={basicInfo.description}
                  onChange={handleBasicInfoChange}
                />
              </Grid>
            </Grid>
          </Box>
        );
      case 1:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Investimentos Iniciais
            </Typography>
            <Grid container spacing={3}>
              {investments.map((investment, index) => (
                <React.Fragment key={index}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label={investment.category}
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={investment.value}
                      onChange={(e) => handleInvestmentChange(index, 'value', Number(e.target.value))}
                      InputProps={{
                        startAdornment: <InputAdornment position="start">R$</InputAdornment>,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Vida Útil (anos)"
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={investment.lifespan}
                      onChange={(e) => handleInvestmentChange(index, 'lifespan', Number(e.target.value))}
                      disabled={investment.category === 'Capital de Giro' || investment.category === 'Marketing Inicial'}
                    />
                  </Grid>
                </React.Fragment>
              ))}
              <Grid item xs={12}>
                <Divider sx={{ my: 2 }} />
                <Typography variant="subtitle1" gutterBottom>
                  Total de Investimentos: R$ {totalInvestment.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </Typography>
              </Grid>
            </Grid>
          </Box>
        );
      case 2:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Projeção de Receitas
            </Typography>
            
            {revenues.map((revenue, index) => (
              <Card key={index} sx={{ mb: 3, p: 2 }}>
                <CardContent>
                  <Grid container spacing={3}>
                    <Grid item xs={12}>
                      <Box display="flex" justifyContent="space-between" alignItems="center">
                        <Typography variant="subtitle1" fontWeight="medium">
                          {`Produto/Serviço ${index + 1}`}
                        </Typography>
                        {revenues.length > 1 && (
                          <IconButton 
                            color="error" 
                            onClick={() => removeRevenue(index)}
                            size="small"
                          >
                            <DeleteIcon />
                          </IconButton>
                        )}
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        label="Nome do Produto/Serviço"
                        fullWidth
                        variant="outlined"
                        value={revenue.name}
                        onChange={(e) => handleRevenueChange(index, 'name', e.target.value)}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <TextField
                        label="Preço Unitário"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={revenue.unitPrice}
                        onChange={(e) => handleRevenueChange(index, 'unitPrice', Number(e.target.value))}
                        InputProps={{
                          startAdornment: <InputAdornment position="start">R$</InputAdornment>,
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={3}>
                      <TextField
                        label="Quantidade Mensal"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={revenue.monthlyQuantity}
                        onChange={(e) => handleRevenueChange(index, 'monthlyQuantity', Number(e.target.value))}
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            ))}
            
            <Box display="flex" justifyContent="center" mb={4}>
              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={addRevenue}
              >
                Adicionar Produto/Serviço
              </Button>
            </Box>
            
            <Divider sx={{ my: 3 }} />
            
            <Typography variant="h6" gutterBottom>
              Crescimento Anual de Vendas (%)
            </Typography>
            <Grid container spacing={2}>
              {annualGrowth.map((growth, index) => (
                <Grid item xs={6} sm={4} md={3} lg={2.4} key={index}>
                  <TextField
                    label={`Ano ${index + 2}`}
                    type="number"
                    fullWidth
                    variant="outlined"
                    value={growth}
                    onChange={(e) => handleGrowthChange(index, Number(e.target.value))}
                    InputProps={{
                      endAdornment: <InputAdornment position="end">%</InputAdornment>,
                    }}
                  />
                </Grid>
              ))}
            </Grid>
          </Box>
        );
      case 3:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Custos e Despesas
            </Typography>
            
            <Typography variant="subtitle1" gutterBottom sx={{ mt: 3 }}>
              Custos Variáveis
            </Typography>
            
            {variableCosts.map((cost, index) => (
              <Card key={index} sx={{ mb: 3, p: 2 }}>
                <CardContent>
                  <Typography variant="subtitle2" gutterBottom>
                    {revenues[index]?.name || `Produto/Serviço ${index + 1}`}
                  </Typography>
                  <Grid container spacing={2}>
                    <Grid item xs={6} sm={3}>
                      <TextField
                        label="Matéria-prima"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={cost.rawMaterial}
                        onChange={(e) => handleVariableCostChange(index, 'rawMaterial', Number(e.target.value))}
                        InputProps={{
                          endAdornment: <InputAdornment position="end">%</InputAdornment>,
                        }}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <TextField
                        label="Embalagem"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={cost.packaging}
                        onChange={(e) => handleVariableCostChange(index, 'packaging', Number(e.target.value))}
                        InputProps={{
                          endAdornment: <InputAdornment position="end">%</InputAdornment>,
                        }}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <TextField
                        label="Comissões"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={cost.commissions}
                        onChange={(e) => handleVariableCostChange(index, 'commissions', Number(e.target.value))}
                        InputProps={{
                          endAdornment: <InputAdornment position="end">%</InputAdornment>,
                        }}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <TextField
                        label="Impostos"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={cost.taxes}
                        onChange={(e) => handleVariableCostChange(index, 'taxes', Number(e.target.value))}
                        InputProps={{
                          endAdornment: <InputAdornment position="end">%</InputAdornment>,
                        }}
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            ))}
            
            <Divider sx={{ my: 4 }} />
            
            <Typography variant="subtitle1" gutterBottom>
              Custos e Despesas Fixas Mensais
            </Typography>
            
            <Grid container spacing={3}>
              {fixedCosts.map((cost, index) => (
                <Grid item xs={12} sm={6} md={4} key={index}>
                  <Box display="flex" alignItems="center">
                    <TextField
                      label={cost.name}
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={cost.monthlyValue}
                      onChange={(e) => handleFixedCostChange(index, Number(e.target.value))}
                      InputProps={{
                        startAdornment: <InputAdornment position="start">R$</InputAdornment>,
                      }}
                    />
                    {index >= 7 && (
                      <IconButton 
                        color="error" 
                        onClick={() => removeFixedCost(index)}
                        size="small"
                        sx={{ ml: 1 }}
                      >
                        <DeleteIcon />
                      </IconButton>
                    )}
                  </Box>
                </Grid>
              ))}
              <Grid item xs={12}>
                <Box display="flex" justifyContent="center" mt={2}>
                  <Button
                    variant="outlined"
                    startIcon={<AddIcon />}
                    onClick={addFixedCost}
                  >
                    Adicionar Custo Fixo
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </Box>
        );
      case 4:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Financiamento
            </Typography>
            
            <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
              Valor Total do Investimento: R$ {totalInvestment.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </Typography>
            
            <Card sx={{ mb: 4, mt: 3 }}>
              <CardContent>
                <Typography variant="subtitle1" gutterBottom>
                  Fonte de Capital
                </Typography>
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Capital Próprio (%)"
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={financing.ownCapital}
                      onChange={(e) => handleFinancingChange('ownCapital', Number(e.target.value))}
                      InputProps={{
                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Financiamento (%)"
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={100 - financing.ownCapital}
                      InputProps={{
                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                        readOnly: true,
                      }}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
            
            <Card sx={{ mb: 4 }}>
              <CardContent>
                <Typography variant="subtitle1" gutterBottom>
                  Detalhes do Financiamento
                </Typography>
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Taxa de Juros Anual"
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={financing.annualInterestRate}
                      onChange={(e) => handleFinancingChange('annualInterestRate', Number(e.target.value))}
                      InputProps={{
                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Prazo (meses)"
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={financing.termMonths}
                      onChange={(e) => handleFinancingChange('termMonths', Number(e.target.value))}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      label="Carência (meses)"
                      type="number"
                      fullWidth
                      variant="outlined"
                      value={financing.graceMonths}
                      onChange={(e) => handleFinancingChange('graceMonths', Number(e.target.value))}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <FormControl fullWidth variant="outlined">
                      <InputLabel id="financing-system-label">Sistema</InputLabel>
                      <Select
                        labelId="financing-system-label"
                        id="financing-system"
                        value={financing.system}
                        onChange={(e) => handleFinancingChange('system', e.target.value)}
                        label="Sistema"
                      >
                        <MenuItem value="SAC">SAC</MenuItem>
                        <MenuItem value="PRICE">PRICE</MenuItem>
                      </Select>
                      <FormHelperText>
                        SAC: Amortizações iguais | PRICE: Parcelas iguais
                      </FormHelperText>
                    </FormControl>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
            
            <Typography variant="subtitle1" gutterBottom>
              Valor do Financiamento: R$ {(totalInvestment * (100 - financing.ownCapital) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </Typography>
          </Box>
        );
      default:
        return 'Passo desconhecido';
    }
  };

  return (
    <Container maxWidth="lg">
      <Paper sx={{ p: { xs: 2, md: 4 }, mb: 4, borderRadius: 2 }}>
        <Typography variant="h4" align="center" gutterBottom>
          Simulação Financeira
        </Typography>
        
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4, pt: 2 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        <Box>
          {getStepContent(activeStep)}
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
            <Button
              variant="outlined"
              disabled={activeStep === 0}
              onClick={handleBack}
              startIcon={<ArrowBackIcon />}
            >
              Voltar
            </Button>
            
            {activeStep === steps.length - 1 ? (
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                endIcon={<ArrowForwardIcon />}
              >
                Calcular Resultados
              </Button>
            ) : (
              <Button
                variant="contained"
                color="primary"
                onClick={handleNext}
                endIcon={<ArrowForwardIcon />}
              >
                Próximo
              </Button>
            )}
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default SimulationFormPage;

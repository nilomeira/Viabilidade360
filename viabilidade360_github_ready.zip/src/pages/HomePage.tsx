import React from 'react';
import { 
  Typography, 
  Box, 
  Container, 
  Paper, 
  Button, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  List,
  ListItem,
  ListItemText,
  Divider
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import BarChartIcon from '@mui/icons-material/BarChart';
import TimelineIcon from '@mui/icons-material/Timeline';
import AssessmentIcon from '@mui/icons-material/Assessment';

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  // Simulação de projetos recentes
  const recentProjects = [
    { id: 1, name: 'Cafeteria', date: '15/04/2025' },
    { id: 2, name: 'E-commerce de Roupas', date: '10/04/2025' },
    { id: 3, name: 'Consultoria de Marketing', date: '05/04/2025' },
  ];

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4, textAlign: 'center' }}>
        <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
          Simulador Financeiro
        </Typography>
        <Typography variant="h5" component="h2" gutterBottom color="text.secondary" sx={{ mb: 6 }}>
          Valide suas ideias de negócios com análises financeiras precisas
        </Typography>

        <Grid container spacing={4} justifyContent="center" sx={{ mb: 6 }}>
          <Grid item xs={12} md={6}>
            <Button
              variant="contained"
              color="primary"
              size="large"
              fullWidth
              startIcon={<AddCircleOutlineIcon />}
              onClick={() => navigate('/simulation')}
              sx={{ 
                py: 2, 
                fontSize: '1.1rem',
                boxShadow: '0 4px 6px rgba(50, 50, 93, 0.11), 0 1px 3px rgba(0, 0, 0, 0.08)',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08)',
                },
                transition: 'all 0.3s',
              }}
            >
              Nova Simulação
            </Button>
          </Grid>
          <Grid item xs={12} md={6}>
            <Button
              variant="outlined"
              color="primary"
              size="large"
              fullWidth
              startIcon={<FolderOpenIcon />}
              sx={{ 
                py: 2, 
                fontSize: '1.1rem',
                '&:hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08)',
                },
                transition: 'all 0.3s',
              }}
            >
              Carregar Simulação
            </Button>
          </Grid>
        </Grid>

        <Paper elevation={0} sx={{ p: 3, borderRadius: 2, bgcolor: 'background.paper', mb: 6 }}>
          <Typography variant="h6" component="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
            Simulações Recentes
          </Typography>
          <List>
            {recentProjects.map((project, index) => (
              <React.Fragment key={project.id}>
                {index > 0 && <Divider component="li" />}
                <ListItem 
                  button 
                  sx={{ 
                    py: 2,
                    '&:hover': {
                      bgcolor: 'rgba(25, 118, 210, 0.08)',
                    },
                  }}
                >
                  <ListItemText 
                    primary={project.name} 
                    secondary={`Editado em ${project.date}`} 
                    primaryTypographyProps={{ fontWeight: 'medium' }}
                  />
                </ListItem>
              </React.Fragment>
            ))}
          </List>
        </Paper>

        <Typography variant="h5" component="h2" gutterBottom sx={{ mb: 4, fontWeight: 'medium' }}>
          Recursos do Simulador
        </Typography>

        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <Card sx={{ 
              height: '100%', 
              display: 'flex', 
              flexDirection: 'column',
              transition: 'transform 0.3s, box-shadow 0.3s',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: '0 10px 20px rgba(0,0,0,0.1)',
              },
            }}>
              <CardContent sx={{ flexGrow: 1, textAlign: 'center', pt: 4 }}>
                <BarChartIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" component="h3" gutterBottom>
                  Análise Financeira Completa
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Calcule DRE, fluxo de caixa e indicadores de viabilidade como TIR, VPL e Payback para validar seu modelo de negócio.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ 
              height: '100%', 
              display: 'flex', 
              flexDirection: 'column',
              transition: 'transform 0.3s, box-shadow 0.3s',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: '0 10px 20px rgba(0,0,0,0.1)',
              },
            }}>
              <CardContent sx={{ flexGrow: 1, textAlign: 'center', pt: 4 }}>
                <TimelineIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" component="h3" gutterBottom>
                  Projeções para 10 Anos
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Visualize a evolução financeira do seu negócio ao longo do tempo com projeções detalhadas para 10 anos.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card sx={{ 
              height: '100%', 
              display: 'flex', 
              flexDirection: 'column',
              transition: 'transform 0.3s, box-shadow 0.3s',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: '0 10px 20px rgba(0,0,0,0.1)',
              },
            }}>
              <CardContent sx={{ flexGrow: 1, textAlign: 'center', pt: 4 }}>
                <AssessmentIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
                <Typography variant="h6" component="h3" gutterBottom>
                  Comparação de Cenários
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Compare diferentes cenários (otimista, realista e pessimista) para entender os riscos e oportunidades do seu negócio.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default HomePage;

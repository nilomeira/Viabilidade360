import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Card, 
  CardContent, 
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Tabs,
  Tab,
  Divider,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import DownloadIcon from '@mui/icons-material/Download';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

// Importação dos componentes de gráficos (simulados aqui)
const LineChart = () => (
  <Box sx={{ height: 300, bgcolor: 'rgba(25, 118, 210, 0.1)', borderRadius: 2, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Typography variant="body2" color="text.secondary">Gráfico de Linha (Simulado)</Typography>
  </Box>
);

const BarChart = () => (
  <Box sx={{ height: 300, bgcolor: 'rgba(25, 118, 210, 0.1)', borderRadius: 2, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Typography variant="body2" color="text.secondary">Gráfico de Barras (Simulado)</Typography>
  </Box>
);

// Interface para a TabPanel
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// Componente TabPanel
const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Dados simulados para os cenários
const simulatedScenarios = {
  pessimistic: {
    irr: 15.2,
    npv: 120450,
    paybackPeriod: 4.5,
    breakEvenPoint: 18000,
    netProfit: [8000, 12000, 18000, 25000, 32000]
  },
  realistic: {
    irr: 24.5,
    npv: 235678,
    paybackPeriod: 3.2,
    breakEvenPoint: 15000,
    netProfit: [13600, 20400, 30600, 40800, 51000]
  },
  optimistic: {
    irr: 32.8,
    npv: 350890,
    paybackPeriod: 2.6,
    breakEvenPoint: 13500,
    netProfit: [19200, 28800, 43200, 57600, 72000]
  }
};

const ScenariosPage: React.FC = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Comparação de Cenários
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Análise de diferentes cenários para seu negócio
        </Typography>
      </Box>

      <Grid container spacing={4}>
        {/* Tabela comparativa de indicadores */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Comparação de Indicadores
            </Typography>
            
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Indicador</TableCell>
                    <TableCell align="center" sx={{ bgcolor: 'error.light', color: 'white' }}>Pessimista</TableCell>
                    <TableCell align="center" sx={{ bgcolor: 'primary.light', color: 'white' }}>Realista</TableCell>
                    <TableCell align="center" sx={{ bgcolor: 'success.light', color: 'white' }}>Otimista</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell component="th" scope="row">TIR</TableCell>
                    <TableCell align="center">{simulatedScenarios.pessimistic.irr}%</TableCell>
                    <TableCell align="center">{simulatedScenarios.realistic.irr}%</TableCell>
                    <TableCell align="center">{simulatedScenarios.optimistic.irr}%</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">VPL</TableCell>
                    <TableCell align="center">R$ {simulatedScenarios.pessimistic.npv.toLocaleString('pt-BR')}</TableCell>
                    <TableCell align="center">R$ {simulatedScenarios.realistic.npv.toLocaleString('pt-BR')}</TableCell>
                    <TableCell align="center">R$ {simulatedScenarios.optimistic.npv.toLocaleString('pt-BR')}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Payback</TableCell>
                    <TableCell align="center">{simulatedScenarios.pessimistic.paybackPeriod} anos</TableCell>
                    <TableCell align="center">{simulatedScenarios.realistic.paybackPeriod} anos</TableCell>
                    <TableCell align="center">{simulatedScenarios.optimistic.paybackPeriod} anos</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" scope="row">Ponto de Equilíbrio</TableCell>
                    <TableCell align="center">R$ {simulatedScenarios.pessimistic.breakEvenPoint.toLocaleString('pt-BR')}</TableCell>
                    <TableCell align="center">R$ {simulatedScenarios.realistic.breakEvenPoint.toLocaleString('pt-BR')}</TableCell>
                    <TableCell align="center">R$ {simulatedScenarios.optimistic.breakEvenPoint.toLocaleString('pt-BR')}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>

        {/* Gráficos e Análises */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Evolução do Lucro Líquido
            </Typography>
            <LineChart />
            
            <Box sx={{ mt: 4 }}>
              <Typography variant="subtitle1" gutterBottom>
                Lucro Líquido por Ano (R$)
              </Typography>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Cenário</TableCell>
                      <TableCell align="right">Ano 1</TableCell>
                      <TableCell align="right">Ano 2</TableCell>
                      <TableCell align="right">Ano 3</TableCell>
                      <TableCell align="right">Ano 4</TableCell>
                      <TableCell align="right">Ano 5</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell component="th" scope="row">Pessimista</TableCell>
                      {simulatedScenarios.pessimistic.netProfit.map((value, index) => (
                        <TableCell key={index} align="right">
                          R$ {value.toLocaleString('pt-BR')}
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow>
                      <TableCell component="th" scope="row">Realista</TableCell>
                      {simulatedScenarios.realistic.netProfit.map((value, index) => (
                        <TableCell key={index} align="right">
                          R$ {value.toLocaleString('pt-BR')}
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow>
                      <TableCell component="th" scope="row">Otimista</TableCell>
                      {simulatedScenarios.optimistic.netProfit.map((value, index) => (
                        <TableCell key={index} align="right">
                          R$ {value.toLocaleString('pt-BR')}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </Paper>
        </Grid>

        {/* Parâmetros dos cenários */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Parâmetros dos Cenários
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12} md={4}>
                <Card sx={{ bgcolor: 'error.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Cenário Pessimista
                    </Typography>
                    <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)', my: 1 }} />
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="body2" gutterBottom>
                        • Vendas: -20% do cenário realista
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        • Custos: +10% do cenário realista
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        • Crescimento anual: -2% em relação ao realista
                      </Typography>
                      <Typography variant="body2">
                        • Impostos: +2% em relação ao realista
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card sx={{ bgcolor: 'primary.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Cenário Realista
                    </Typography>
                    <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)', my: 1 }} />
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="body2" gutterBottom>
                        • Vendas: conforme projeção informada
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        • Custos: conforme informados
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        • Crescimento anual: conforme projeção
                      </Typography>
                      <Typography variant="body2">
                        • Impostos: conforme legislação atual
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card sx={{ bgcolor: 'success.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Cenário Otimista
                    </Typography>
                    <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)', my: 1 }} />
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="body2" gutterBottom>
                        • Vendas: +20% do cenário realista
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        • Custos: -5% do cenário realista
                      </Typography>
                      <Typography variant="body2" gutterBottom>
                        • Crescimento anual: +2% em relação ao realista
                      </Typography>
                      <Typography variant="body2">
                        • Impostos: sem alteração
                      </Typography>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
            
            <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center' }}>
              <Button variant="outlined">
                Editar Parâmetros
              </Button>
            </Box>
          </Paper>
        </Grid>

        {/* Botões de ação */}
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <Button
              variant="outlined"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate('/dashboard')}
            >
              Voltar ao Dashboard
            </Button>
            
            <Button
              variant="contained"
              color="primary"
              startIcon={<DownloadIcon />}
              onClick={() => navigate('/reports')}
            >
              Gerar Relatórios
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ScenariosPage;

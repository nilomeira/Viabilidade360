import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Card, 
  CardContent,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Divider
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import SimulationManager from '../utils/SimulationManager';
import ReportService from '../components/ReportService';
import { SimulationInput, ScenarioResults } from '../types/financialTypes';

// Interface para a TabPanel
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// Componente TabPanel
const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

const ExportReportsPage: React.FC = () => {
  const navigate = useNavigate();
  const simulationManager = SimulationManager.getInstance();
  const [tabValue, setTabValue] = useState(0);
  const [simulationData, setSimulationData] = useState<{input: SimulationInput | null, results: ScenarioResults | null}>({
    input: null,
    results: null
  });

  useEffect(() => {
    // Carregar dados da simulação
    const input = simulationManager.getSimulationInput();
    const results = simulationManager.getSimulationResults();
    
    setSimulationData({
      input,
      results
    });
    
    // Redirecionar para a página inicial se não houver dados
    if (!input || !results) {
      navigate('/');
    }
  }, [navigate, simulationManager]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  // Formatar valores monetários
  const formatCurrency = (value: number) => {
    return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Exportação de Relatórios
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Gere relatórios detalhados da sua simulação financeira
        </Typography>
      </Box>

      <Grid container spacing={4}>
        {/* Painel de Relatórios */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Relatórios Disponíveis
            </Typography>
            <Box sx={{ mt: 3 }}>
              <ReportService />
            </Box>
          </Paper>
        </Grid>
        
        {/* Visualização de Dados */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs value={tabValue} onChange={handleTabChange} variant="fullWidth">
                <Tab label="Resumo" />
                <Tab label="DRE" />
                <Tab label="Fluxo de Caixa" />
                <Tab label="Indicadores" />
              </Tabs>
            </Box>

            <TabPanel value={tabValue} index={0}>
              <Typography variant="h6" gutterBottom>
                Resumo da Simulação
              </Typography>
              
              {simulationData.input && simulationData.results && (
                <Box>
                  <Typography variant="subtitle1" gutterBottom>
                    {simulationData.input.basicInfo.projectName || 'Novo Projeto'}
                  </Typography>
                  
                  <Grid container spacing={3}>
                    <Grid item xs={12} sm={6}>
                      <Card>
                        <CardContent>
                          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                            Investimento Total
                          </Typography>
                          <Typography variant="h5">
                            {formatCurrency(simulationData.input.investments.reduce((sum, inv) => sum + inv.value, 0))}
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <Card>
                        <CardContent>
                          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                            TIR (Cenário Realista)
                          </Typography>
                          <Typography variant="h5">
                            {simulationData.results.realistic.summary.irr}%
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <Card>
                        <CardContent>
                          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                            VPL (Cenário Realista)
                          </Typography>
                          <Typography variant="h5">
                            {formatCurrency(simulationData.results.realistic.summary.npv)}
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    
                    <Grid item xs={12} sm={6}>
                      <Card>
                        <CardContent>
                          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                            Payback (Cenário Realista)
                          </Typography>
                          <Typography variant="h5">
                            {simulationData.results.realistic.summary.paybackPeriod} anos
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>
                </Box>
              )}
            </TabPanel>
            
            <TabPanel value={tabValue} index={1}>
              <Typography variant="h6" gutterBottom>
                Demonstrativo de Resultados (DRE)
              </Typography>
              
              {simulationData.results && (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Ano</TableCell>
                        <TableCell align="right">Receita Bruta</TableCell>
                        <TableCell align="right">Receita Líquida</TableCell>
                        <TableCell align="right">Lucro Operacional</TableCell>
                        <TableCell align="right">Lucro Líquido</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {simulationData.results.realistic.incomeStatement.map((item) => (
                        <TableRow key={item.year}>
                          <TableCell component="th" scope="row">
                            {item.year}
                          </TableCell>
                          <TableCell align="right">{formatCurrency(item.grossRevenue)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.netRevenue)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.operatingProfit)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.netProfit)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
              
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                * O relatório completo contém todos os detalhes do DRE para cada ano.
              </Typography>
            </TabPanel>
            
            <TabPanel value={tabValue} index={2}>
              <Typography variant="h6" gutterBottom>
                Fluxo de Caixa
              </Typography>
              
              {simulationData.results && (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Ano</TableCell>
                        <TableCell align="right">Fluxo Operacional</TableCell>
                        <TableCell align="right">Fluxo de Investimento</TableCell>
                        <TableCell align="right">Fluxo de Financiamento</TableCell>
                        <TableCell align="right">Fluxo Líquido</TableCell>
                        <TableCell align="right">Fluxo Acumulado</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {simulationData.results.realistic.cashFlow.map((item) => (
                        <TableRow key={item.year}>
                          <TableCell component="th" scope="row">
                            {item.year}
                          </TableCell>
                          <TableCell align="right">{formatCurrency(item.operationalCashFlow)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.investmentCashFlow)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.financingCashFlow)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.netCashFlow)}</TableCell>
                          <TableCell align="right">{formatCurrency(item.accumulatedCashFlow)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
              
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                * Ano 0 representa o momento inicial do investimento.
              </Typography>
            </TabPanel>
            
            <TabPanel value={tabValue} index={3}>
              <Typography variant="h6" gutterBottom>
                Indicadores Financeiros
              </Typography>
              
              {simulationData.results && (
                <Grid container spacing={3}>
                  <Grid item xs={12}>
                    <TableContainer>
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell>Indicador</TableCell>
                            <TableCell align="center">Pessimista</TableCell>
                            <TableCell align="center">Realista</TableCell>
                            <TableCell align="center">Otimista</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow>
                            <TableCell component="th" scope="row">TIR</TableCell>
                            <TableCell align="center">{simulationData.results.pessimistic.summary.irr}%</TableCell>
                            <TableCell align="center">{simulationData.results.realistic.summary.irr}%</TableCell>
                            <TableCell align="center">{simulationData.results.optimistic.summary.irr}%</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell component="th" scope="row">VPL</TableCell>
                            <TableCell align="center">{formatCurrency(simulationData.results.pessimistic.summary.npv)}</TableCell>
                            <TableCell align="center">{formatCurrency(simulationData.results.realistic.summary.npv)}</TableCell>
                            <TableCell align="center">{formatCurrency(simulationData.results.optimistic.summary.npv)}</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell component="th" scope="row">Payback</TableCell>
                            <TableCell align="center">{simulationData.results.pessimistic.summary.paybackPeriod} anos</TableCell>
                            <TableCell align="center">{simulationData.results.realistic.summary.paybackPeriod} anos</TableCell>
                            <TableCell align="center">{simulationData.results.optimistic.summary.paybackPeriod} anos</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell component="th" scope="row">Payback Descontado</TableCell>
                            <TableCell align="center">{simulationData.results.pessimistic.summary.discountedPaybackPeriod} anos</TableCell>
                            <TableCell align="center">{simulationData.results.realistic.summary.discountedPaybackPeriod} anos</TableCell>
                            <TableCell align="center">{simulationData.results.optimistic.summary.discountedPaybackPeriod} anos</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell component="th" scope="row">Ponto de Equilíbrio</TableCell>
                            <TableCell align="center">{formatCurrency(simulationData.results.pessimistic.summary.breakEvenPoint)}/mês</TableCell>
                            <TableCell align="center">{formatCurrency(simulationData.results.realistic.summary.breakEvenPoint)}/mês</TableCell>
                            <TableCell align="center">{formatCurrency(simulationData.results.optimistic.summary.breakEvenPoint)}/mês</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Grid>
                  
                  <Grid item xs={12}>
                    <Divider sx={{ my: 2 }} />
                    <Typography variant="subtitle1" gutterBottom>
                      Interpretação dos Resultados
                    </Typography>
                    
                    <Box sx={{ mt: 2 }}>
                      {simulationData.results.realistic.summary.irr > (simulationData.input?.basicInfo.discountRate || 0) ? (
                        <Typography variant="body2" paragraph>
                          A Taxa Interna de Retorno (TIR) de {simulationData.results.realistic.summary.irr}% está acima da taxa mínima de atratividade de {simulationData.input?.basicInfo.discountRate || 0}%, indicando que o projeto é viável financeiramente.
                        </Typography>
                      ) : (
                        <Typography variant="body2" paragraph>
                          A Taxa Interna de Retorno (TIR) de {simulationData.results.realistic.summary.irr}% está abaixo da taxa mínima de atratividade de {simulationData.input?.basicInfo.discountRate || 0}%, indicando riscos na viabilidade financeira do projeto.
                        </Typography>
                      )}
                      
                      {simulationData.results.realistic.summary.npv > 0 ? (
                        <Typography variant="body2" paragraph>
                          O Valor Presente Líquido (VPL) positivo de {formatCurrency(simulationData.results.realistic.summary.npv)} indica que o investimento gerará valor para o empreendedor.
                        </Typography>
                      ) : (
                        <Typography variant="body2" paragraph>
                          O Valor Presente Líquido (VPL) negativo de {formatCurrency(simulationData.results.realistic.summary.npv)} indica que o investimento não gerará valor suficiente para o empreendedor.
                        </Typography>
                      )}
                      
                      <Typography variant="body2" paragraph>
                        O tempo de retorno do investimento (Payback) é de {simulationData.results.realistic.summary.paybackPeriod} anos, e considerando o valor do dinheiro no tempo (Payback Descontado) é de {simulationData.results.realistic.summary.discountedPaybackPeriod} anos.
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>
              )}
            </TabPanel>
          </Paper>
        </Grid>
        
        {/* Botões de ação */}
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <Button
              variant="outlined"
              onClick={() => navigate('/dashboard')}
            >
              Voltar ao Dashboard
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ExportReportsPage;

import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Card, 
  CardContent, 
  Tabs,
  Tab,
  Button,
  Divider,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import DownloadIcon from '@mui/icons-material/Download';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

// Importação dos componentes de gráficos (simulados aqui)
const LineChart = () => (
  <Box sx={{ height: 300, bgcolor: 'rgba(25, 118, 210, 0.1)', borderRadius: 2, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Typography variant="body2" color="text.secondary">Gráfico de Linha (Simulado)</Typography>
  </Box>
);

const BarChart = () => (
  <Box sx={{ height: 300, bgcolor: 'rgba(25, 118, 210, 0.1)', borderRadius: 2, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Typography variant="body2" color="text.secondary">Gráfico de Barras (Simulado)</Typography>
  </Box>
);

const PieChart = () => (
  <Box sx={{ height: 300, bgcolor: 'rgba(25, 118, 210, 0.1)', borderRadius: 2, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <Typography variant="body2" color="text.secondary">Gráfico de Pizza (Simulado)</Typography>
  </Box>
);

// Interface para a TabPanel
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// Componente TabPanel
const TabPanel = (props: TabPanelProps) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ pt: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Dados simulados para o dashboard
const simulatedData = {
  summary: {
    irr: 24.5, // TIR
    npv: 235678.9, // VPL
    paybackPeriod: 3.2, // Payback em anos
    breakEvenPoint: 15000, // Ponto de equilíbrio mensal
  },
  incomeStatement: {
    year1: {
      grossRevenue: 240000,
      taxes: 36000,
      netRevenue: 204000,
      variableCosts: 72000,
      grossMargin: 132000,
      fixedCosts: 96000,
      operatingProfit: 36000,
      depreciation: 12000,
      interest: 8000,
      ebt: 16000,
      incomeTax: 2400,
      netProfit: 13600
    }
  },
  cashFlow: {
    year0: -100000,
    year1: 25000,
    year2: 35000,
    year3: 45000,
    year4: 55000,
    year5: 65000
  }
};

const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Dashboard de Resultados
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Análise financeira completa da sua simulação
        </Typography>
      </Box>

      <Grid container spacing={4}>
        {/* Indicadores principais */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Typography variant="h6" gutterBottom>
              Resumo dos Indicadores
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={6} sm={3}>
                <Card sx={{ height: '100%', bgcolor: 'primary.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="overline" component="div">
                      TIR
                    </Typography>
                    <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
                      {simulatedData.summary.irr}%
                    </Typography>
                    <Typography variant="body2">
                      Taxa Interna de Retorno
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={6} sm={3}>
                <Card sx={{ height: '100%', bgcolor: 'secondary.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="overline" component="div">
                      VPL
                    </Typography>
                    <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
                      R$ {simulatedData.summary.npv.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
                    </Typography>
                    <Typography variant="body2">
                      Valor Presente Líquido
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={6} sm={3}>
                <Card sx={{ height: '100%', bgcolor: 'success.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="overline" component="div">
                      Payback
                    </Typography>
                    <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
                      {simulatedData.summary.paybackPeriod} anos
                    </Typography>
                    <Typography variant="body2">
                      Tempo de Retorno
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={6} sm={3}>
                <Card sx={{ height: '100%', bgcolor: 'info.light', color: 'white' }}>
                  <CardContent>
                    <Typography variant="overline" component="div">
                      Ponto de Equilíbrio
                    </Typography>
                    <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
                      R$ {simulatedData.summary.breakEvenPoint.toLocaleString('pt-BR')}
                    </Typography>
                    <Typography variant="body2">
                      Faturamento Mensal Mínimo
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* Gráficos e Análises */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3, borderRadius: 2 }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs 
                value={tabValue} 
                onChange={handleTabChange} 
                variant={isMobile ? "scrollable" : "fullWidth"}
                scrollButtons={isMobile ? "auto" : undefined}
              >
                <Tab label="Fluxo de Caixa" />
                <Tab label="DRE" />
                <Tab label="Indicadores" />
              </Tabs>
            </Box>

            <TabPanel value={tabValue} index={0}>
              <Typography variant="subtitle1" gutterBottom>
                Evolução do Fluxo de Caixa
              </Typography>
              <LineChart />
              
              <Box sx={{ mt: 4 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Fluxo de Caixa Acumulado
                </Typography>
                <Grid container spacing={2}>
                  {Object.entries(simulatedData.cashFlow).map(([year, value], index) => (
                    <Grid item xs={6} sm={4} md={2} key={index}>
                      <Card sx={{ 
                        bgcolor: value < 0 ? 'error.light' : 'success.light', 
                        color: 'white',
                        textAlign: 'center',
                        p: 1
                      }}>
                        <Typography variant="subtitle2">
                          {year.replace('year', 'Ano ')}
                        </Typography>
                        <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                          R$ {value.toLocaleString('pt-BR')}
                        </Typography>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </TabPanel>

            <TabPanel value={tabValue} index={1}>
              <Typography variant="subtitle1" gutterBottom>
                Demonstrativo de Resultados - Ano 1
              </Typography>
              <Grid container spacing={4}>
                <Grid item xs={12} md={6}>
                  <BarChart />
                </Grid>
                <Grid item xs={12} md={6}>
                  <Card sx={{ height: '100%' }}>
                    <CardContent>
                      <Typography variant="subtitle2" gutterBottom>
                        DRE Simplificado - Ano 1
                      </Typography>
                      <Box sx={{ mt: 2 }}>
                        <Grid container spacing={1}>
                          <Grid item xs={8}>
                            <Typography variant="body2">Receita Bruta:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.grossRevenue.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2">(-) Impostos:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.taxes.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                              (=) Receita Líquida:
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right" sx={{ fontWeight: 'medium' }}>
                              R$ {simulatedData.incomeStatement.year1.netRevenue.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2">(-) Custos Variáveis:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.variableCosts.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                              (=) Margem Bruta:
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right" sx={{ fontWeight: 'medium' }}>
                              R$ {simulatedData.incomeStatement.year1.grossMargin.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2">(-) Despesas Fixas:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.fixedCosts.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                              (=) Lucro Operacional:
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right" sx={{ fontWeight: 'medium' }}>
                              R$ {simulatedData.incomeStatement.year1.operatingProfit.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2">(-) Depreciação:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.depreciation.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2">(-) Juros:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.interest.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                              (=) Lucro Antes IR:
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right" sx={{ fontWeight: 'medium' }}>
                              R$ {simulatedData.incomeStatement.year1.ebt.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body2">(-) IR:</Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body2" align="right">
                              R$ {simulatedData.incomeStatement.year1.incomeTax.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                          
                          <Grid item xs={12}>
                            <Divider sx={{ my: 1 }} />
                          </Grid>
                          
                          <Grid item xs={8}>
                            <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                              (=) Lucro Líquido:
                            </Typography>
                          </Grid>
                          <Grid item xs={4}>
                            <Typography variant="body1" align="right" sx={{ fontWeight: 'bold' }}>
                              R$ {simulatedData.incomeStatement.year1.netProfit.toLocaleString('pt-BR')}
                            </Typography>
                          </Grid>
                        </Grid>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </TabPanel>

            <TabPanel value={tabValue} index={2}>
              <Typography variant="subtitle1" gutterBottom>
                Análise de Indicadores
              </Typography>
              <Grid container spacing={4}>
                <Grid item xs={12} md={6}>
                  <PieChart />
                </Grid>
                <Grid item xs={12} md={6}>
                  <Card sx={{ height: '100%' }}>
                    <CardContent>
                      <Typography variant="subtitle2" gutterBottom>
                        Interpretação dos Indicadores
                      </Typography>
                      
                      <Box sx={{ mt: 2 }}>
                        <Typography variant="body2" gutterBottom sx={{ fontWeight: 'medium' }}>
                          TIR: {simulatedData.summary.irr}%
                        </Typography>
                        <Typography variant="body2" paragraph>
                          A Taxa Interna de Retorno está acima da taxa mínima de atratividade, indicando que o projeto é viável financeiramente.
                        </Typography>
                        
                        <Typography variant="body2" gutterBottom sx={{ fontWeight: 'medium' }}>
                          VPL: R$ {simulatedData.summary.npv.toLocaleString('pt-BR')}
                        </Typography>
                        <Typography variant="body2" paragraph>
                          O Valor Presente Líquido positivo indica que o investimento gerará valor para o empreendedor.
                        </Typography>
                        
                        <Typography variant="body2" gutterBottom sx={{ fontWeight: 'medium' }}>
                          Payback: {simulatedData.summary.paybackPeriod} anos
                        </Typography>
                        <Typography variant="body2" paragraph>
                          O tempo de retorno do investimento é considerado bom para o setor, demonstrando que o capital investido será recuperado em um período razoável.
                        </Typography>
                        
                        <Typography variant="body2" gutterBottom sx={{ fontWeight: 'medium' }}>
                          Ponto de Equilíbrio: R$ {simulatedData.summary.breakEvenPoint.toLocaleString('pt-BR')}/mês
                        </Typography>
                        <Typography variant="body2">
                          Este é o faturamento mensal mínimo necessário para cobrir todos os custos e despesas do negócio.
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </TabPanel>
          </Paper>
        </Grid>

        {/* Botões de ação */}
        <Grid item xs={12}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
            <Button
              variant="outlined"
              startIcon={<CompareArrowsIcon />}
              onClick={() => navigate('/scenarios')}
            >
              Comparar Cenários
            </Button>
            
            <Button
              variant="contained"
              color="primary"
              startIcon={<PictureAsPdfIcon />}
              onClick={() => navigate('/reports')}
            >
              Ver Relatórios Detalhados
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
};

export default DashboardPage;

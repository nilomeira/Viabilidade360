import { SimulationInput } from '../types/financialTypes';

/**
 * Caso de teste para uma pequena loja de roupas
 */
export const testCaseSmallClothingStore = (): SimulationInput => {
  return {
    basicInfo: {
      projectName: "Boutique de Roupas",
      sector: "Varejo de Moda",
      startDate: "2025-05-01",
      projectionPeriod: 10,
      currency: "BRL",
      discountRate: 12,
      description: "Loja de roupas femininas em shopping center"
    },
    investments: [
      {
        category: "Reforma e Decoração",
        value: 80000,
        lifespan: 10
      },
      {
        category: "Mobiliário e Equipamentos",
        value: 45000,
        lifespan: 5
      },
      {
        category: "Estoque Inicial",
        value: 120000,
        lifespan: 1
      },
      {
        category: "Marketing de Lançamento",
        value: 15000,
        lifespan: 1
      },
      {
        category: "Sistemas e Software",
        value: 8000,
        lifespan: 3
      }
    ],
    revenues: [
      {
        name: "Roupas Casuais",
        unitPrice: 150,
        monthlyQuantity: 200
      },
      {
        name: "Roupas Sociais",
        unitPrice: 280,
        monthlyQuantity: 100
      },
      {
        name: "Acessórios",
        unitPrice: 80,
        monthlyQuantity: 150
      }
    ],
    annualGrowth: [5, 8, 10, 12, 8, 6, 5, 4, 3, 2],
    variableCosts: [
      {
        productId: 0,
        rawMaterial: 40,
        packaging: 2,
        commissions: 5,
        taxes: 12
      },
      {
        productId: 1,
        rawMaterial: 45,
        packaging: 2,
        commissions: 5,
        taxes: 12
      },
      {
        productId: 2,
        rawMaterial: 35,
        packaging: 1,
        commissions: 5,
        taxes: 12
      }
    ],
    fixedCosts: [
      {
        name: "Aluguel",
        monthlyValue: 12000
      },
      {
        name: "Salários",
        monthlyValue: 18000
      },
      {
        name: "Água, Luz e Internet",
        monthlyValue: 1500
      },
      {
        name: "Contabilidade",
        monthlyValue: 800
      },
      {
        name: "Marketing",
        monthlyValue: 3000
      },
      {
        name: "Manutenção",
        monthlyValue: 500
      }
    ],
    financing: {
      ownCapital: 40,
      loanAmount: 0,
      annualInterestRate: 15,
      termMonths: 60,
      graceMonths: 3,
      system: "SAC"
    }
  };
};

/**
 * Caso de teste para uma cafeteria
 */
export const testCaseCoffeeShop = (): SimulationInput => {
  return {
    basicInfo: {
      projectName: "Café Especial",
      sector: "Alimentação",
      startDate: "2025-06-01",
      projectionPeriod: 10,
      currency: "BRL",
      discountRate: 10,
      description: "Cafeteria especializada em grãos especiais e ambiente aconchegante"
    },
    investments: [
      {
        category: "Reforma do Espaço",
        value: 60000,
        lifespan: 10
      },
      {
        category: "Equipamentos de Cozinha",
        value: 85000,
        lifespan: 8
      },
      {
        category: "Mobiliário",
        value: 35000,
        lifespan: 5
      },
      {
        category: "Estoque Inicial",
        value: 20000,
        lifespan: 1
      },
      {
        category: "Marketing de Lançamento",
        value: 12000,
        lifespan: 1
      }
    ],
    revenues: [
      {
        name: "Cafés Especiais",
        unitPrice: 12,
        monthlyQuantity: 3000
      },
      {
        name: "Salgados e Doces",
        unitPrice: 15,
        monthlyQuantity: 2000
      },
      {
        name: "Bebidas Não-Alcoólicas",
        unitPrice: 8,
        monthlyQuantity: 1500
      }
    ],
    annualGrowth: [8, 12, 15, 10, 8, 6, 5, 4, 3, 2],
    variableCosts: [
      {
        productId: 0,
        rawMaterial: 30,
        packaging: 5,
        commissions: 0,
        taxes: 12
      },
      {
        productId: 1,
        rawMaterial: 40,
        packaging: 5,
        commissions: 0,
        taxes: 12
      },
      {
        productId: 2,
        rawMaterial: 25,
        packaging: 5,
        commissions: 0,
        taxes: 12
      }
    ],
    fixedCosts: [
      {
        name: "Aluguel",
        monthlyValue: 8000
      },
      {
        name: "Salários",
        monthlyValue: 22000
      },
      {
        name: "Água, Luz e Gás",
        monthlyValue: 2500
      },
      {
        name: "Contabilidade",
        monthlyValue: 800
      },
      {
        name: "Marketing",
        monthlyValue: 1500
      },
      {
        name: "Manutenção",
        monthlyValue: 800
      }
    ],
    financing: {
      ownCapital: 30,
      loanAmount: 0,
      annualInterestRate: 12,
      termMonths: 48,
      graceMonths: 6,
      system: "SAC"
    }
  };
};

/**
 * Caso de teste para uma empresa de software
 */
export const testCaseSoftwareCompany = (): SimulationInput => {
  return {
    basicInfo: {
      projectName: "Tech Solutions",
      sector: "Tecnologia",
      startDate: "2025-07-01",
      projectionPeriod: 10,
      currency: "BRL",
      discountRate: 15,
      description: "Empresa de desenvolvimento de software para gestão empresarial"
    },
    investments: [
      {
        category: "Desenvolvimento Inicial",
        value: 200000,
        lifespan: 5
      },
      {
        category: "Equipamentos e Infraestrutura",
        value: 80000,
        lifespan: 3
      },
      {
        category: "Marketing e Vendas",
        value: 50000,
        lifespan: 1
      },
      {
        category: "Escritório",
        value: 30000,
        lifespan: 5
      }
    ],
    revenues: [
      {
        name: "Licenças de Software",
        unitPrice: 5000,
        monthlyQuantity: 10
      },
      {
        name: "Serviços de Implementação",
        unitPrice: 15000,
        monthlyQuantity: 3
      },
      {
        name: "Suporte Técnico",
        unitPrice: 1000,
        monthlyQuantity: 50
      }
    ],
    annualGrowth: [20, 30, 40, 35, 25, 20, 15, 10, 8, 5],
    variableCosts: [
      {
        productId: 0,
        rawMaterial: 10,
        packaging: 0,
        commissions: 15,
        taxes: 15
      },
      {
        productId: 1,
        rawMaterial: 60,
        packaging: 0,
        commissions: 10,
        taxes: 15
      },
      {
        productId: 2,
        rawMaterial: 40,
        packaging: 0,
        commissions: 5,
        taxes: 15
      }
    ],
    fixedCosts: [
      {
        name: "Aluguel",
        monthlyValue: 6000
      },
      {
        name: "Salários",
        monthlyValue: 80000
      },
      {
        name: "Infraestrutura de TI",
        monthlyValue: 5000
      },
      {
        name: "Contabilidade e Jurídico",
        monthlyValue: 3000
      },
      {
        name: "Marketing",
        monthlyValue: 8000
      },
      {
        name: "Viagens e Representação",
        monthlyValue: 4000
      }
    ],
    financing: {
      ownCapital: 25,
      loanAmount: 0,
      annualInterestRate: 18,
      termMonths: 60,
      graceMonths: 12,
      system: "SAC"
    }
  };
};

import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { SimulationInput, SimulationResult, IncomeStatementItem, CashFlowItem } from '../types/financialTypes';

/**
 * Classe para geração de relatórios em PDF
 */
export class ReportGenerator {
  private doc: any;
  private input: SimulationInput;
  private result: SimulationResult;
  private pageWidth: number;
  private margin: number;
  private contentWidth: number;

  /**
   * Construtor
   * @param input Dados de entrada da simulação
   * @param result Resultados da simulação
   */
  constructor(input: SimulationInput, result: SimulationResult) {
    this.input = input;
    this.result = result;
    this.doc = new jsPDF();
    this.pageWidth = this.doc.internal.pageSize.width;
    this.margin = 20;
    this.contentWidth = this.pageWidth - (this.margin * 2);
  }

  /**
   * Gera o relatório completo em PDF
   * @returns Objeto PDF
   */
  public generateFullReport(): any {
    this.addCoverPage();
    this.doc.addPage();
    this.addSummaryPage();
    this.doc.addPage();
    this.addIncomeStatementPage();
    this.doc.addPage();
    this.addCashFlowPage();
    this.doc.addPage();
    this.addFinancialIndicatorsPage();
    
    return this.doc;
  }

  /**
   * Gera apenas o relatório de DRE
   * @returns Objeto PDF
   */
  public generateIncomeStatementReport(): any {
    this.addCoverPage();
    this.doc.addPage();
    this.addIncomeStatementPage();
    
    return this.doc;
  }

  /**
   * Gera apenas o relatório de Fluxo de Caixa
   * @returns Objeto PDF
   */
  public generateCashFlowReport(): any {
    this.addCoverPage();
    this.doc.addPage();
    this.addCashFlowPage();
    
    return this.doc;
  }

  /**
   * Gera apenas o relatório de Indicadores Financeiros
   * @returns Objeto PDF
   */
  public generateFinancialIndicatorsReport(): any {
    this.addCoverPage();
    this.doc.addPage();
    this.addFinancialIndicatorsPage();
    
    return this.doc;
  }

  /**
   * Adiciona a página de capa ao relatório
   */
  private addCoverPage(): void {
    const title = 'Relatório de Simulação Financeira';
    const projectName = this.input.basicInfo.projectName || 'Novo Projeto';
    const date = new Date().toLocaleDateString('pt-BR');

    // Título
    this.doc.setFontSize(24);
    this.doc.setTextColor(25, 118, 210); // Cor primária
    this.doc.text(title, this.pageWidth / 2, 80, { align: 'center' });

    // Nome do projeto
    this.doc.setFontSize(18);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text(projectName, this.pageWidth / 2, 100, { align: 'center' });

    // Data
    this.doc.setFontSize(12);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text(`Gerado em: ${date}`, this.pageWidth / 2, 120, { align: 'center' });

    // Informações do projeto
    this.doc.setFontSize(12);
    this.doc.setTextColor(0, 0, 0);
    
    const infoY = 150;
    this.doc.text(`Setor: ${this.input.basicInfo.sector || 'Não especificado'}`, this.margin, infoY);
    this.doc.text(`Período de Projeção: ${this.input.basicInfo.projectionPeriod} anos`, this.margin, infoY + 10);
    this.doc.text(`Taxa de Desconto: ${this.input.basicInfo.discountRate}%`, this.margin, infoY + 20);
    
    // Rodapé
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('Simulador Financeiro para Validação de Ideias de Negócios', this.pageWidth / 2, 280, { align: 'center' });
  }

  /**
   * Adiciona a página de resumo ao relatório
   */
  private addSummaryPage(): void {
    // Título
    this.doc.setFontSize(18);
    this.doc.setTextColor(25, 118, 210);
    this.doc.text('Resumo da Simulação', this.pageWidth / 2, 20, { align: 'center' });

    // Linha separadora
    this.doc.setDrawColor(200, 200, 200);
    this.doc.line(this.margin, 25, this.pageWidth - this.margin, 25);

    // Resumo dos indicadores
    this.doc.setFontSize(14);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text('Indicadores Financeiros', this.margin, 40);

    this.doc.setFontSize(12);
    const indicators = [
      { name: 'Taxa Interna de Retorno (TIR)', value: `${this.result.summary.irr}%` },
      { name: 'Valor Presente Líquido (VPL)', value: `R$ ${this.result.summary.npv.toLocaleString('pt-BR')}` },
      { name: 'Payback', value: `${this.result.summary.paybackPeriod} anos` },
      { name: 'Payback Descontado', value: `${this.result.summary.discountedPaybackPeriod} anos` },
      { name: 'Ponto de Equilíbrio Mensal', value: `R$ ${this.result.summary.breakEvenPoint.toLocaleString('pt-BR')}` }
    ];

    let y = 50;
    indicators.forEach(indicator => {
      this.doc.text(`${indicator.name}: ${indicator.value}`, this.margin, y);
      y += 10;
    });

    // Resumo dos investimentos
    y += 10;
    this.doc.setFontSize(14);
    this.doc.text('Investimentos', this.margin, y);
    y += 10;

    this.doc.setFontSize(12);
    const totalInvestment = this.input.investments.reduce((sum, inv) => sum + inv.value, 0);
    this.doc.text(`Investimento Total: R$ ${totalInvestment.toLocaleString('pt-BR')}`, this.margin, y);
    
    // Resumo das receitas
    y += 20;
    this.doc.setFontSize(14);
    this.doc.text('Receitas', this.margin, y);
    y += 10;

    this.doc.setFontSize(12);
    const firstYearRevenue = this.result.incomeStatement[0].grossRevenue;
    this.doc.text(`Receita Bruta (Ano 1): R$ ${firstYearRevenue.toLocaleString('pt-BR')}`, this.margin, y);
    
    // Resumo dos custos
    y += 20;
    this.doc.setFontSize(14);
    this.doc.text('Custos e Despesas', this.margin, y);
    y += 10;

    this.doc.setFontSize(12);
    const firstYearVariableCosts = this.result.incomeStatement[0].variableCosts;
    const firstYearFixedCosts = this.result.incomeStatement[0].fixedCosts;
    this.doc.text(`Custos Variáveis (Ano 1): R$ ${firstYearVariableCosts.toLocaleString('pt-BR')}`, this.margin, y);
    y += 10;
    this.doc.text(`Custos Fixos (Ano 1): R$ ${firstYearFixedCosts.toLocaleString('pt-BR')}`, this.margin, y);
    
    // Resumo do financiamento
    y += 20;
    this.doc.setFontSize(14);
    this.doc.text('Financiamento', this.margin, y);
    y += 10;

    this.doc.setFontSize(12);
    const loanAmount = totalInvestment * (100 - this.input.financing.ownCapital) / 100;
    this.doc.text(`Capital Próprio: R$ ${(totalInvestment - loanAmount).toLocaleString('pt-BR')} (${this.input.financing.ownCapital}%)`, this.margin, y);
    y += 10;
    this.doc.text(`Financiamento: R$ ${loanAmount.toLocaleString('pt-BR')} (${100 - this.input.financing.ownCapital}%)`, this.margin, y);
  }

  /**
   * Adiciona a página de DRE ao relatório
   */
  private addIncomeStatementPage(): void {
    // Título
    this.doc.setFontSize(18);
    this.doc.setTextColor(25, 118, 210);
    this.doc.text('Demonstrativo de Resultados do Exercício (DRE)', this.pageWidth / 2, 20, { align: 'center' });

    // Linha separadora
    this.doc.setDrawColor(200, 200, 200);
    this.doc.line(this.margin, 25, this.pageWidth - this.margin, 25);

    // Tabela de DRE
    const headers = [
      { header: 'Ano', dataKey: 'year' },
      { header: 'Receita Bruta', dataKey: 'grossRevenue' },
      { header: 'Impostos', dataKey: 'taxes' },
      { header: 'Receita Líquida', dataKey: 'netRevenue' },
      { header: 'Custos Variáveis', dataKey: 'variableCosts' },
      { header: 'Margem Bruta', dataKey: 'grossMargin' },
      { header: 'Custos Fixos', dataKey: 'fixedCosts' },
      { header: 'EBITDA', dataKey: 'operatingProfit' },
      { header: 'Depreciação', dataKey: 'depreciation' },
      { header: 'Juros', dataKey: 'interest' },
      { header: 'Lucro Antes IR', dataKey: 'ebt' },
      { header: 'IR', dataKey: 'incomeTax' },
      { header: 'Lucro Líquido', dataKey: 'netProfit' }
    ];

    const data = this.result.incomeStatement.map(item => {
      return {
        year: item.year,
        grossRevenue: this.formatCurrency(item.grossRevenue),
        taxes: this.formatCurrency(item.taxes),
        netRevenue: this.formatCurrency(item.netRevenue),
        variableCosts: this.formatCurrency(item.variableCosts),
        grossMargin: this.formatCurrency(item.grossMargin),
        fixedCosts: this.formatCurrency(item.fixedCosts),
        operatingProfit: this.formatCurrency(item.operatingProfit),
        depreciation: this.formatCurrency(item.depreciation),
        interest: this.formatCurrency(item.interest),
        ebt: this.formatCurrency(item.ebt),
        incomeTax: this.formatCurrency(item.incomeTax),
        netProfit: this.formatCurrency(item.netProfit)
      };
    });

    (this.doc as any).autoTable({
      startY: 35,
      head: [headers.map(h => h.header)],
      body: data.map(d => headers.map(h => d[h.dataKey as keyof typeof d])),
      theme: 'grid',
      styles: {
        fontSize: 8,
        cellPadding: 2
      },
      headStyles: {
        fillColor: [25, 118, 210],
        textColor: [255, 255, 255],
        fontStyle: 'bold'
      },
      columnStyles: {
        0: { cellWidth: 15 }
      },
      margin: { left: this.margin, right: this.margin }
    });

    // Explicação
    const tableEnd = (this.doc as any).lastAutoTable.finalY + 10;
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('O Demonstrativo de Resultados do Exercício (DRE) apresenta o desempenho financeiro projetado', this.margin, tableEnd);
    this.doc.text('para cada ano do período de análise, mostrando a formação do resultado líquido a partir das receitas e despesas.', this.margin, tableEnd + 5);
  }

  /**
   * Adiciona a página de Fluxo de Caixa ao relatório
   */
  private addCashFlowPage(): void {
    // Título
    this.doc.setFontSize(18);
    this.doc.setTextColor(25, 118, 210);
    this.doc.text('Fluxo de Caixa Projetado', this.pageWidth / 2, 20, { align: 'center' });

    // Linha separadora
    this.doc.setDrawColor(200, 200, 200);
    this.doc.line(this.margin, 25, this.pageWidth - this.margin, 25);

    // Tabela de Fluxo de Caixa
    const headers = [
      { header: 'Ano', dataKey: 'year' },
      { header: 'Fluxo Operacional', dataKey: 'operationalCashFlow' },
      { header: 'Fluxo de Investimento', dataKey: 'investmentCashFlow' },
      { header: 'Fluxo de Financiamento', dataKey: 'financingCashFlow' },
      { header: 'Fluxo Líquido', dataKey: 'netCashFlow' },
      { header: 'Fluxo Acumulado', dataKey: 'accumulatedCashFlow' }
    ];

    const data = this.result.cashFlow.map(item => {
      return {
        year: item.year,
        operationalCashFlow: this.formatCurrency(item.operationalCashFlow),
        investmentCashFlow: this.formatCurrency(item.investmentCashFlow),
        financingCashFlow: this.formatCurrency(item.financingCashFlow),
        netCashFlow: this.formatCurrency(item.netCashFlow),
        accumulatedCashFlow: this.formatCurrency(item.accumulatedCashFlow)
      };
    });

    (this.doc as any).autoTable({
      startY: 35,
      head: [headers.map(h => h.header)],
      body: data.map(d => headers.map(h => d[h.dataKey as keyof typeof d])),
      theme: 'grid',
      styles: {
        fontSize: 10,
        cellPadding: 3
      },
      headStyles: {
        fillColor: [25, 118, 210],
        textColor: [255, 255, 255],
        fontStyle: 'bold'
      },
      columnStyles: {
        0: { cellWidth: 20 }
      },
      margin: { left: this.margin, right: this.margin }
    });

    // Explicação
    const tableEnd = (this.doc as any).lastAutoTable.finalY + 10;
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('O Fluxo de Caixa Projetado mostra as entradas e saídas de dinheiro ao longo do tempo,', this.margin, tableEnd);
    this.doc.text('permitindo visualizar a liquidez do negócio e o retorno do investimento.', this.margin, tableEnd + 5);
    this.doc.text('Ano 0 representa o momento inicial do investimento.', this.margin, tableEnd + 15);
  }

  /**
   * Adiciona a página de Indicadores Financeiros ao relatório
   */
  private addFinancialIndicatorsPage(): void {
    // Título
    this.doc.setFontSize(18);
    this.doc.setTextColor(25, 118, 210);
    this.doc.text('Análise de Indicadores Financeiros', this.pageWidth / 2, 20, { align: 'center' });

    // Linha separadora
    this.doc.setDrawColor(200, 200, 200);
    this.doc.line(this.margin, 25, this.pageWidth - this.margin, 25);

    // Indicadores
    this.doc.setFontSize(14);
    this.doc.setTextColor(0, 0, 0);
    
    let y = 40;
    
    // TIR
    this.doc.text('Taxa Interna de Retorno (TIR)', this.margin, y);
    y += 8;
    this.doc.setFontSize(12);
    this.doc.text(`Valor: ${this.result.summary.irr}%`, this.margin + 10, y);
    y += 8;
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('A TIR representa a taxa de retorno do investimento. Quanto maior a TIR em relação à', this.margin + 10, y);
    this.doc.text(`taxa mínima de atratividade (${this.input.basicInfo.discountRate}%), mais atrativo é o investimento.`, this.margin + 10, y + 5);
    
    // VPL
    y += 20;
    this.doc.setFontSize(14);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text('Valor Presente Líquido (VPL)', this.margin, y);
    y += 8;
    this.doc.setFontSize(12);
    this.doc.text(`Valor: R$ ${this.result.summary.npv.toLocaleString('pt-BR')}`, this.margin + 10, y);
    y += 8;
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('O VPL representa o valor atual dos fluxos de caixa futuros descontados à taxa mínima de', this.margin + 10, y);
    this.doc.text('atratividade. Um VPL positivo indica que o investimento é economicamente viável.', this.margin + 10, y + 5);
    
    // Payback
    y += 20;
    this.doc.setFontSize(14);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text('Payback', this.margin, y);
    y += 8;
    this.doc.setFontSize(12);
    this.doc.text(`Payback Simples: ${this.result.summary.paybackPeriod} anos`, this.margin + 10, y);
    y += 8;
    this.doc.text(`Payback Descontado: ${this.result.summary.discountedPaybackPeriod} anos`, this.margin + 10, y);
    y += 8;
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('O Payback representa o tempo necessário para recuperar o investimento inicial.', this.margin + 10, y);
    this.doc.text('O Payback Descontado considera o valor do dinheiro no tempo.', this.margin + 10, y + 5);
    
    // Ponto de Equilíbrio
    y += 20;
    this.doc.setFontSize(14);
    this.doc.setTextColor(0, 0, 0);
    this.doc.text('Ponto de Equilíbrio', this.margin, y);
    y += 8;
    this.doc.setFontSize(12);
    this.doc.text(`Valor Mensal: R$ ${this.result.summary.breakEvenPoint.toLocaleString('pt-BR')}`, this.margin + 10, y);
    y += 8;
    this.doc.setFontSize(10);
    this.doc.setTextColor(100, 100, 100);
    this.doc.text('O Ponto de Equilíbrio representa o faturamento mínimo necessário para cobrir todos os', this.margin + 10, y);
    this.doc.text('custos e despesas do negócio, sem gerar lucro ou prejuízo.', this.margin + 10, y + 5);
    
    // Conclusão
    y += 20;
    this.doc.setFontSize(14);
    this.doc.setTextColor(25, 118, 210);
    this.doc.text('Conclusão', this.margin, y);
    y += 8;
    this.doc.setFontSize(10);
    this.doc.setTextColor(0, 0, 0);
    
    let conclusion = '';
    if (this.result.summary.irr > this.input.basicInfo.discountRate && this.result.summary.npv > 0) {
      conclusion = 'Com base nos indicadores financeiros calculados, o projeto apresenta viabilidade econômica, ' +
                  'com TIR superior à taxa mínima de atratividade e VPL positivo. O tempo de retorno do investimento ' +
                  'está dentro de um período aceitável.';
    } else {
      conclusion = 'Com base nos indicadores financeiros calculados, o projeto apresenta riscos econômicos, ' +
                  'pois a TIR está próxima ou abaixo da taxa mínima de atratividade ou o VPL está próximo de zero. ' +
                  'Recomenda-se revisar as premissas ou buscar alternativas para melhorar a viabilidade.';
    }
    
    this.doc.text(conclusion, this.margin + 10, y, { maxWidth: this.contentWidth - 20 });
  }

  /**
   * Formata um valor numérico como moeda
   * @param value Valor a ser formatado
   * @returns String formatada
   */
  private formatCurrency(value: number): string {
    return `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
}

export default ReportGenerator;

import { SimulationInput, ScenarioResults } from '../types/financialTypes';
import { runFinancialSimulation } from './financialCalculations';

/**
 * Classe para gerenciar o estado da simulação financeira
 */
export class SimulationManager {
  private static instance: SimulationManager;
  private simulationInput: SimulationInput | null = null;
  private simulationResults: ScenarioResults | null = null;

  private constructor() {}

  /**
   * Obtém a instância única do SimulationManager (Singleton)
   */
  public static getInstance(): SimulationManager {
    if (!SimulationManager.instance) {
      SimulationManager.instance = new SimulationManager();
    }
    return SimulationManager.instance;
  }

  /**
   * Define os dados de entrada da simulação
   * @param input Dados de entrada da simulação
   */
  public setSimulationInput(input: SimulationInput): void {
    this.simulationInput = input;
  }

  /**
   * Obtém os dados de entrada da simulação
   * @returns Dados de entrada da simulação
   */
  public getSimulationInput(): SimulationInput | null {
    return this.simulationInput;
  }

  /**
   * Executa a simulação financeira
   * @returns Resultados da simulação
   */
  public runSimulation(): ScenarioResults | null {
    if (!this.simulationInput) {
      console.error('Não há dados de entrada para executar a simulação');
      return null;
    }

    try {
      this.simulationResults = runFinancialSimulation(this.simulationInput);
      return this.simulationResults;
    } catch (error) {
      console.error('Erro ao executar a simulação:', error);
      return null;
    }
  }

  /**
   * Obtém os resultados da simulação
   * @returns Resultados da simulação
   */
  public getSimulationResults(): ScenarioResults | null {
    return this.simulationResults;
  }

  /**
   * Salva a simulação atual no localStorage
   * @param name Nome da simulação
   */
  public saveSimulation(name: string): void {
    if (!this.simulationInput || !this.simulationResults) {
      console.error('Não há dados para salvar');
      return;
    }

    try {
      const savedSimulations = this.getSavedSimulations();
      
      const simulationData = {
        name,
        date: new Date().toISOString(),
        input: this.simulationInput,
        results: this.simulationResults
      };

      savedSimulations[name] = simulationData;
      localStorage.setItem('savedSimulations', JSON.stringify(savedSimulations));
    } catch (error) {
      console.error('Erro ao salvar a simulação:', error);
    }
  }

  /**
   * Carrega uma simulação salva
   * @param name Nome da simulação
   * @returns Verdadeiro se a simulação foi carregada com sucesso
   */
  public loadSimulation(name: string): boolean {
    try {
      const savedSimulations = this.getSavedSimulations();
      const simulationData = savedSimulations[name];

      if (!simulationData) {
        console.error('Simulação não encontrada');
        return false;
      }

      this.simulationInput = simulationData.input;
      this.simulationResults = simulationData.results;
      return true;
    } catch (error) {
      console.error('Erro ao carregar a simulação:', error);
      return false;
    }
  }

  /**
   * Obtém todas as simulações salvas
   * @returns Objeto com todas as simulações salvas
   */
  public getSavedSimulations(): Record<string, any> {
    try {
      const savedSimulationsJson = localStorage.getItem('savedSimulations');
      return savedSimulationsJson ? JSON.parse(savedSimulationsJson) : {};
    } catch (error) {
      console.error('Erro ao obter simulações salvas:', error);
      return {};
    }
  }

  /**
   * Exclui uma simulação salva
   * @param name Nome da simulação
   * @returns Verdadeiro se a simulação foi excluída com sucesso
   */
  public deleteSimulation(name: string): boolean {
    try {
      const savedSimulations = this.getSavedSimulations();
      
      if (!savedSimulations[name]) {
        console.error('Simulação não encontrada');
        return false;
      }

      delete savedSimulations[name];
      localStorage.setItem('savedSimulations', JSON.stringify(savedSimulations));
      return true;
    } catch (error) {
      console.error('Erro ao excluir a simulação:', error);
      return false;
    }
  }

  /**
   * Limpa os dados da simulação atual
   */
  public clearSimulation(): void {
    this.simulationInput = null;
    this.simulationResults = null;
  }
}

export default SimulationManager;

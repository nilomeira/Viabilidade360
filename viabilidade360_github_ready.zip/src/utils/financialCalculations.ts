/**
 * Módulo de cálculos financeiros para o simulador
 * Implementa todos os algoritmos necessários para calcular indicadores financeiros
 */

import { 
  SimulationInput, 
  SimulationResult, 
  IncomeStatementItem, 
  CashFlowItem, 
  FinancialIndicators,
  ScenarioResults
} from '../types/financialTypes';

/**
 * Calcula o Demonstrativo de Resultados do Exercício (DRE) para todos os anos
 * @param input Dados de entrada da simulação
 * @returns Array com o DRE de cada ano
 */
export const calculateIncomeStatement = (input: SimulationInput): IncomeStatementItem[] => {
  const statements: IncomeStatementItem[] = [];
  
  for (let year = 1; year <= input.basicInfo.projectionPeriod; year++) {
    // Calcular receita bruta anual com crescimento
    const growthFactor = year === 1 ? 1 : (1 + input.annualGrowth[year-2] / 100);
    let grossRevenue = 0;
    
    input.revenues.forEach(revenue => {
      // Cálculo da receita anual considerando crescimento acumulado
      let accumulatedGrowth = 1;
      if (year > 1) {
        for (let i = 0; i < year - 1; i++) {
          accumulatedGrowth *= (1 + (input.annualGrowth[i] || 0) / 100);
        }
      }
      
      const annualRevenue = revenue.unitPrice * revenue.monthlyQuantity * 12 * accumulatedGrowth;
      grossRevenue += annualRevenue;
    });
    
    // Calcular impostos sobre receita (média de 15%)
    const taxRate = 0.15;
    const taxes = grossRevenue * taxRate;
    
    // Calcular receita líquida
    const netRevenue = grossRevenue - taxes;
    
    // Calcular custos variáveis
    let variableCosts = 0;
    input.variableCosts.forEach((cost, index) => {
      if (index < input.revenues.length) {
        const revenue = input.revenues[index];
        const totalCostPercentage = cost.rawMaterial + cost.packaging + cost.commissions + cost.taxes;
        
        // Mesmo cálculo de crescimento acumulado
        let accumulatedGrowth = 1;
        if (year > 1) {
          for (let i = 0; i < year - 1; i++) {
            accumulatedGrowth *= (1 + (input.annualGrowth[i] || 0) / 100);
          }
        }
        
        const annualCost = revenue.unitPrice * revenue.monthlyQuantity * 12 * accumulatedGrowth * (totalCostPercentage / 100);
        variableCosts += annualCost;
      }
    });
    
    // Calcular margem bruta
    const grossMargin = netRevenue - variableCosts;
    
    // Calcular custos fixos
    let fixedCosts = 0;
    input.fixedCosts.forEach(cost => {
      fixedCosts += cost.monthlyValue * 12;
    });
    
    // Calcular lucro operacional (EBITDA)
    const operatingProfit = grossMargin - fixedCosts;
    
    // Calcular depreciação
    let depreciation = 0;
    input.investments.forEach(investment => {
      if (investment.lifespan > 0 && year <= investment.lifespan) {
        depreciation += investment.value / investment.lifespan;
      }
    });
    
    // Calcular juros do financiamento
    let interest = 0;
    if (input.financing && input.financing.loanAmount > 0) {
      // Cálculo simplificado de juros
      const totalInvestment = input.investments.reduce((sum, inv) => sum + inv.value, 0);
      const loanAmount = totalInvestment * (100 - input.financing.ownCapital) / 100;
      
      const remainingYears = Math.max(0, Math.ceil(input.financing.termMonths / 12) - (year - 1));
      if (remainingYears > 0 && year > Math.floor(input.financing.graceMonths / 12)) {
        // Durante o período de carência, apenas juros são pagos
        if (year <= Math.ceil(input.financing.graceMonths / 12)) {
          interest = loanAmount * (input.financing.annualInterestRate / 100);
        } else {
          // Após a carência, juros sobre o saldo devedor
          const paymentYears = Math.ceil(input.financing.termMonths / 12) - Math.ceil(input.financing.graceMonths / 12);
          const amortizationPerYear = loanAmount / paymentYears;
          const yearsAfterGrace = year - Math.ceil(input.financing.graceMonths / 12);
          const remainingPrincipal = loanAmount - (amortizationPerYear * (yearsAfterGrace - 1));
          
          if (remainingPrincipal > 0) {
            interest = remainingPrincipal * (input.financing.annualInterestRate / 100);
          }
        }
      }
    }
    
    // Calcular lucro antes do IR
    const ebt = operatingProfit - depreciation - interest;
    
    // Calcular IR (exemplo: 15%)
    const incomeTaxRate = 0.15;
    const incomeTax = Math.max(0, ebt * incomeTaxRate);
    
    // Calcular lucro líquido
    const netProfit = ebt - incomeTax;
    
    statements.push({
      year,
      grossRevenue,
      taxes,
      netRevenue,
      variableCosts,
      grossMargin,
      fixedCosts,
      operatingProfit,
      depreciation,
      interest,
      ebt,
      incomeTax,
      netProfit
    });
  }
  
  return statements;
};

/**
 * Calcula o Fluxo de Caixa para todos os anos
 * @param input Dados de entrada da simulação
 * @param incomeStatement DRE calculado previamente
 * @returns Array com o Fluxo de Caixa de cada ano
 */
export const calculateCashFlow = (
  input: SimulationInput, 
  incomeStatement: IncomeStatementItem[]
): CashFlowItem[] => {
  const cashFlows: CashFlowItem[] = [];
  
  // Calcular investimento total
  const totalInvestment = input.investments.reduce((sum, inv) => sum + inv.value, 0);
  
  // Calcular valor do financiamento
  const loanAmount = totalInvestment * (100 - input.financing.ownCapital) / 100;
  
  // Fluxo de caixa inicial (ano 0)
  cashFlows.push({
    year: 0,
    operationalCashFlow: 0,
    investmentCashFlow: -totalInvestment,
    financingCashFlow: loanAmount,
    netCashFlow: -totalInvestment + loanAmount,
    accumulatedCashFlow: -totalInvestment + loanAmount
  });
  
  // Fluxo de caixa para os anos seguintes
  for (let year = 1; year <= input.basicInfo.projectionPeriod; year++) {
    const statement = incomeStatement[year - 1];
    
    // Fluxo de caixa operacional = Lucro líquido + Depreciação
    const operationalCashFlow = statement.netProfit + statement.depreciation;
    
    // Fluxo de caixa de investimento (reinvestimentos, se houver)
    let investmentCashFlow = 0;
    
    // Fluxo de caixa de financiamento (pagamento do empréstimo)
    let financingCashFlow = 0;
    if (loanAmount > 0) {
      const paymentYears = Math.ceil(input.financing.termMonths / 12) - Math.ceil(input.financing.graceMonths / 12);
      
      // Após o período de carência, começam as amortizações
      if (year > Math.ceil(input.financing.graceMonths / 12) && year <= Math.ceil(input.financing.termMonths / 12)) {
        const amortizationPerYear = loanAmount / paymentYears;
        financingCashFlow = -amortizationPerYear;
      }
    }
    
    // Fluxo de caixa líquido
    const netCashFlow = operationalCashFlow + investmentCashFlow + financingCashFlow;
    
    // Fluxo de caixa acumulado
    const previousAccumulatedCashFlow = cashFlows[cashFlows.length - 1].accumulatedCashFlow;
    const accumulatedCashFlow = previousAccumulatedCashFlow + netCashFlow;
    
    cashFlows.push({
      year,
      operationalCashFlow,
      investmentCashFlow,
      financingCashFlow,
      netCashFlow,
      accumulatedCashFlow
    });
  }
  
  return cashFlows;
};

/**
 * Calcula a Taxa Interna de Retorno (TIR)
 * @param cashFlows Fluxo de caixa calculado previamente
 * @returns TIR em percentual
 */
export const calculateIRR = (cashFlows: CashFlowItem[]): number => {
  // Extrair apenas os fluxos de caixa líquidos para o cálculo da TIR
  const cashFlowValues = cashFlows.map(cf => cf.netCashFlow);
  
  // Implementação do método de Newton-Raphson para encontrar a TIR
  let guess = 0.1; // Estimativa inicial de 10%
  const maxIterations = 100;
  const tolerance = 0.0001;
  
  for (let i = 0; i < maxIterations; i++) {
    const npv = calculateNPVWithRate(cashFlowValues, guess);
    const derivative = calculateNPVDerivative(cashFlowValues, guess);
    
    if (Math.abs(derivative) < tolerance) {
      break;
    }
    
    const newGuess = guess - npv / derivative;
    
    if (Math.abs(newGuess - guess) < tolerance) {
      guess = newGuess;
      break;
    }
    
    guess = newGuess;
  }
  
  // Converter para percentual
  return Math.round(guess * 10000) / 100;
};

/**
 * Função auxiliar para calcular o VPL com uma taxa específica
 */
const calculateNPVWithRate = (cashFlows: number[], rate: number): number => {
  let npv = 0;
  
  for (let i = 0; i < cashFlows.length; i++) {
    npv += cashFlows[i] / Math.pow(1 + rate, i);
  }
  
  return npv;
};

/**
 * Função auxiliar para calcular a derivada do VPL
 */
const calculateNPVDerivative = (cashFlows: number[], rate: number): number => {
  let derivative = 0;
  
  for (let i = 1; i < cashFlows.length; i++) {
    derivative -= i * cashFlows[i] / Math.pow(1 + rate, i + 1);
  }
  
  return derivative;
};

/**
 * Calcula o Valor Presente Líquido (VPL)
 * @param cashFlows Fluxo de caixa calculado previamente
 * @param discountRate Taxa de desconto anual (em decimal)
 * @returns VPL
 */
export const calculateNPV = (cashFlows: CashFlowItem[], discountRate: number): number => {
  let npv = 0;
  const rate = discountRate / 100; // Converter de percentual para decimal
  
  for (let i = 0; i < cashFlows.length; i++) {
    npv += cashFlows[i].netCashFlow / Math.pow(1 + rate, i);
  }
  
  return Math.round(npv * 100) / 100;
};

/**
 * Calcula o Payback simples
 * @param cashFlows Fluxo de caixa calculado previamente
 * @returns Payback em anos
 */
export const calculatePayback = (cashFlows: CashFlowItem[]): number => {
  let accumulatedCashFlow = cashFlows[0].netCashFlow;
  let year = 0;
  
  while (accumulatedCashFlow < 0 && year < cashFlows.length - 1) {
    year++;
    accumulatedCashFlow += cashFlows[year].netCashFlow;
  }
  
  if (accumulatedCashFlow < 0) {
    return -1; // Não há payback dentro do período analisado
  }
  
  // Ajuste para fração do ano
  const previousYearCashFlow = accumulatedCashFlow - cashFlows[year].netCashFlow;
  const fraction = (0 - previousYearCashFlow) / cashFlows[year].netCashFlow;
  
  return Math.round((year - 1 + fraction) * 10) / 10;
};

/**
 * Calcula o Payback descontado
 * @param cashFlows Fluxo de caixa calculado previamente
 * @param discountRate Taxa de desconto anual (em percentual)
 * @returns Payback descontado em anos
 */
export const calculateDiscountedPayback = (
  cashFlows: CashFlowItem[], 
  discountRate: number
): number => {
  const rate = discountRate / 100; // Converter de percentual para decimal
  
  // Calcular fluxos de caixa descontados
  const discountedCashFlows = cashFlows.map((cf, index) => ({
    ...cf,
    discountedNetCashFlow: cf.netCashFlow / Math.pow(1 + rate, index)
  }));
  
  let accumulatedDiscountedCashFlow = discountedCashFlows[0].discountedNetCashFlow;
  let year = 0;
  
  while (accumulatedDiscountedCashFlow < 0 && year < discountedCashFlows.length - 1) {
    year++;
    accumulatedDiscountedCashFlow += discountedCashFlows[year].discountedNetCashFlow;
  }
  
  if (accumulatedDiscountedCashFlow < 0) {
    return -1; // Não há payback descontado dentro do período analisado
  }
  
  // Ajuste para fração do ano
  const previousYearDiscountedCashFlow = accumulatedDiscountedCashFlow - discountedCashFlows[year].discountedNetCashFlow;
  const fraction = (0 - previousYearDiscountedCashFlow) / discountedCashFlows[year].discountedNetCashFlow;
  
  return Math.round((year - 1 + fraction) * 10) / 10;
};

/**
 * Calcula o Ponto de Equilíbrio
 * @param input Dados de entrada da simulação
 * @param incomeStatement DRE calculado previamente
 * @returns Ponto de equilíbrio mensal
 */
export const calculateBreakEvenPoint = (
  input: SimulationInput, 
  incomeStatement: IncomeStatementItem[]
): number => {
  // Usando os dados do primeiro ano
  const firstYearStatement = incomeStatement[0];
  
  // Receita anual
  const annualRevenue = firstYearStatement.grossRevenue;
  
  // Custos variáveis anuais
  const annualVariableCosts = firstYearStatement.variableCosts;
  
  // Custos fixos anuais
  const annualFixedCosts = firstYearStatement.fixedCosts;
  
  // Margem de contribuição
  const contributionMargin = annualRevenue - annualVariableCosts;
  
  // Índice de margem de contribuição
  const contributionMarginIndex = contributionMargin / annualRevenue;
  
  // Ponto de equilíbrio anual
  const annualBreakEvenPoint = annualFixedCosts / contributionMarginIndex;
  
  // Ponto de equilíbrio mensal
  const monthlyBreakEvenPoint = annualBreakEvenPoint / 12;
  
  return Math.round(monthlyBreakEvenPoint);
};

/**
 * Gera cenários alternativos (pessimista e otimista)
 * @param input Dados de entrada da simulação
 * @returns Resultados dos três cenários
 */
export const generateScenarios = (input: SimulationInput): ScenarioResults => {
  // Cenário realista (usa os dados de entrada originais)
  const realisticResult = processSimulation(input);
  
  // Cenário pessimista
  const pessimisticInput = JSON.parse(JSON.stringify(input)); // Deep copy
  
  // Reduz receitas em 20%
  pessimisticInput.revenues.forEach((revenue: any) => {
    revenue.monthlyQuantity *= 0.8;
  });
  
  // Aumenta custos em 10%
  pessimisticInput.variableCosts.forEach((cost: any) => {
    cost.rawMaterial *= 1.1;
    cost.packaging *= 1.1;
    cost.commissions *= 1.1;
    cost.taxes *= 1.1;
  });
  
  pessimisticInput.fixedCosts.forEach((cost: any) => {
    cost.monthlyValue *= 1.1;
  });
  
  // Reduz crescimento anual em 2 pontos percentuais
  pessimisticInput.annualGrowth = pessimisticInput.annualGrowth.map((growth: number) => 
    Math.max(0, growth - 2)
  );
  
  const pessimisticResult = processSimulation(pessimisticInput);
  
  // Cenário otimista
  const optimisticInput = JSON.parse(JSON.stringify(input)); // Deep copy
  
  // Aumenta receitas em 20%
  optimisticInput.revenues.forEach((revenue: any) => {
    revenue.monthlyQuantity *= 1.2;
  });
  
  // Reduz custos em 5%
  optimisticInput.variableCosts.forEach((cost: any) => {
    cost.rawMaterial *= 0.95;
    cost.packaging *= 0.95;
    cost.commissions *= 0.95;
    cost.taxes *= 0.95;
  });
  
  optimisticInput.fixedCosts.forEach((cost: any) => {
    cost.monthlyValue *= 0.95;
  });
  
  // Aumenta crescimento anual em 2 pontos percentuais
  optimisticInput.annualGrowth = optimisticInput.annualGrowth.map((growth: number) => 
    growth + 2
  );
  
  const optimisticResult = processSimulation(optimisticInput);
  
  return {
    pessimistic: pessimisticResult,
    realistic: realisticResult,
    optimistic: optimisticResult
  };
};

/**
 * Processa a simulação completa
 * @param input Dados de entrada da simulação
 * @returns Resultados da simulação
 */
export const processSimulation = (input: SimulationInput): SimulationResult => {
  // Calcula DRE
  const incomeStatement = calculateIncomeStatement(input);
  
  // Calcula Fluxo de Caixa
  const cashFlow = calculateCashFlow(input, incomeStatement);
  
  // Calcula indicadores
  const irr = calculateIRR(cashFlow);
  const npv = calculateNPV(cashFlow, input.basicInfo.discountRate);
  const paybackPeriod = calculatePayback(cashFlow);
  const discountedPaybackPeriod = calculateDiscountedPayback(cashFlow, input.basicInfo.discountRate);
  const breakEvenPoint = calculateBreakEvenPoint(input, incomeStatement);
  
  return {
    summary: {
      irr,
      npv,
      paybackPeriod,
      discountedPaybackPeriod,
      breakEvenPoint
    },
    incomeStatement,
    cashFlow
  };
};

/**
 * Função principal para executar a simulação financeira
 * @param input Dados de entrada da simulação
 * @returns Resultados da simulação incluindo cenários
 */
export const runFinancialSimulation = (input: SimulationInput): ScenarioResults => {
  return generateScenarios(input);
};
